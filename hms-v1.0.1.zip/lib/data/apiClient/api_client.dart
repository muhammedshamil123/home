import 'package:hms/core/app_export.dart';

class ApiClient extends GetConnect {}
