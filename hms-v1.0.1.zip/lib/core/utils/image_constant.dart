class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // signup images
  static String imgTelevision = '$imagePath/img_television.svg';

  // create home images
  static String imgCommunication = '$imagePath/img_communication.png';

  static String imgAdd = '$imagePath/img_add.svg';

  // next images
  static String imgBusinessTechnology =
      '$imagePath/img_business_technology.png';

  // address images
  static String imgSortDown = '$imagePath/img_sort_down.png';

  static String imgBoxImportant = '$imagePath/img_box_important.png';

  // savings images
  static String imgGroupIndigo600 = '$imagePath/img_group_indigo_600.svg';

  static String imgNavTransactionsPrimary =
      '$imagePath/img_nav_transactions_primary.svg';

  static String imgPlus = '$imagePath/img_plus.svg';

  // calendar images
  static String imgNavCalendarPrimary =
      '$imagePath/img_nav_calendar_primary.svg';

  // splashscreen images
  static String imgRectangle15 = '$imagePath/img_rectangle_15.png';

  // getstarted images
  static String imgRectangle13 = '$imagePath/img_rectangle_13.png';

  // loginpage images
  static String imgWorkflowWoman = '$imagePath/img_workflow_woman.png';

  static String imgCheckmark = '$imagePath/img_checkmark.svg';

  static String imgUser = '$imagePath/img_user.svg';

  // menubar images
  static String imgArrowLeftPrimarycontainer =
      '$imagePath/img_arrow_left_primarycontainer.svg';

  static String imgLock = '$imagePath/img_lock.svg';

  static String imgUserPrimarycontainer =
      '$imagePath/img_user_primarycontainer.svg';

  static String imgLockPrimarycontainer =
      '$imagePath/img_lock_primarycontainer.svg';

  static String imgGroup66 = '$imagePath/img_group_66.png';

  static String imgVideoCamera = '$imagePath/img_video_camera.svg';

  static String imgUserPrimarycontainer44x44 =
      '$imagePath/img_user_primarycontainer_44x44.svg';

  static String imgArrowRight = '$imagePath/img_arrow_right.svg';

  // settings images
  static String imgArrowRightBlueGray40001 =
      '$imagePath/img_arrow_right_blue_gray_400_01.svg';

  // notifications images
  static String imgCocoLineArrowLightGreenA700 =
      '$imagePath/img_coco_line_arrow_light_green_a700.svg';

  static String imgCocoLineArrowSecondarycontainer =
      '$imagePath/img_coco_line_arrow_secondarycontainer.svg';

  // Statistics images
  static String imgFavorite = '$imagePath/img_favorite.svg';

  static String imgGroup33515 = '$imagePath/img_group_33515.png';

  // Goal images
  static String imgEditPurple300 = '$imagePath/img_edit_purple_300.svg';

  static String imgGroupPurple300 = '$imagePath/img_group_purple_300.svg';

  // Reset Password images
  static String imgInterfaceEssentialLockPassword =
      '$imagePath/img_interface_essential_lock_password.svg';

  static String imgLocation = '$imagePath/img_location.svg';

  static String imgEye = '$imagePath/img_eye.svg';

  // Common images
  static String imgArrowLeft = '$imagePath/img_arrow_left.svg';

  static String imgProfilePicture = '$imagePath/img_profile_picture.png';

  static String imgMenuVertical = '$imagePath/img_menu_vertical.png';

  static String imgNavHome = '$imagePath/img_nav_home.svg';

  static String imgNavTransactions = '$imagePath/img_nav_transactions.svg';

  static String imgNavCalendar = '$imagePath/img_nav_calendar.svg';

  static String imgGroupBlueGray100 = '$imagePath/img_group_blue_gray_100.svg';

  static String imgGroupOnerrorcontainer =
      '$imagePath/img_group_onerrorcontainer.svg';

  static String imgNavHomeBlueGray400 =
      '$imagePath/img_nav_home_blue_gray_400.svg';

  static String imgCocoLineArrow = '$imagePath/img_coco_line_arrow.svg';

  static String imgProfilePicture96x96 =
      '$imagePath/img_profile_picture_96x96.png';

  static String imgProfilePicture1 = '$imagePath/img_profile_picture_1.png';

  static String imgEdit = '$imagePath/img_edit.svg';

  static String imgThumbsUpOnerrorcontainer =
      '$imagePath/img_thumbs_up_onerrorcontainer.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
