final Map<String, String> enUs = {
  // signup Screen
  "lbl_create_password": "Create Password",
  "lbl_sign_up": "Sign Up",
  "lbl_signup2": "SignUp",
  "lbl_your_email": "Your Email",
  "msg_your_family_name": "Your Family Name",

  // create home Screen
  "lbl_create_home": "Create home",
  "msg_create_a_home_to":
      "Create a home to add your favourite devices\n             and actions for quick access.",
  "msg_create_your_home": "Create your home",

  // next Screen
  "lbl_home_nickname": "Home nickname",
  "lbl_it_later": "   it later.",
  "lbl_name_your_home": "Name your home",
  "msg_choose_a_nickname":
      "Choose a nickname for this home to help identify\n                            ",

  // address Screen
  "lbl_address_line_1": "Address line 1",
  "lbl_address_line_2": "Address line 2",
  "lbl_country": "Country",
  "lbl_home_address": "Home address",
  "lbl_like_directions": " like directions",
  "lbl_postcode": "Postcode",
  "lbl_skip": "Skip",
  "lbl_town_city": "Town/City",
  "msg_your_home_address":
      "Your home address  will be used for things\n               like directions",
  "msg_your_home_address2": "Your home address  will be used for things\n",

  // add member Screen
  "lbl_member_email": "Member Email", "lbl_member_name": "Member Name",
  "lbl_role": "Role",

  // main - Container Screen
  "lbl_calendar": "Calendar", "lbl_home": "Home",
  "lbl_transactions": "Transactions",

  // savings Screen
  "lbl_goal_status": "Goal Status",

  // splashscreen Screen
  "lbl_home2": "HOME",

  // getstarted Screen
  "lbl_get_start": "Get  Start",
  "msg_forever_united_together": "  “ forever united\ntogether strong.”",

  // loginpage Screen
  "lbl_email": "Email",
  "lbl_login": "Login",
  "lbl_password": "Password",
  "lbl_sign_up2": "Sign up",
  "msg_don_t_have_an_account": "Don’t have an account",

  // menubar Screen
  "lbl_goal_setup": "Goal Setup", "lbl_log_out": "Log Out", "lbl_menu": "Menu",

  // Add Transactions Screen
  "lbl_add_transaction": "Add Transaction",
  "lbl_amount": "Amount",
  "lbl_category": "Category",
  "lbl_date": "Date",
  "lbl_description": "Description",
  "lbl_save_close": "Save & Close",
  "lbl_time": "Time",
  "lbl_type": "Type",

  // Profile Screen
  "lbl_change": "change", "lbl_delete_account": "Delete Account",
  "msg_personal_details": "Personal Details",

  // Family Screen
  "lbl_delete_family": "Delete  Family", "lbl_family_details": "Family Details",

  // settings Screen
  "lbl_change_password": "Change Password",
  "lbl_english": "English",
  "lbl_general": "General",
  "lbl_language": "Language",
  "lbl_my_profile": "My Profile",
  "lbl_privacy_policy": "Privacy Policy",
  "lbl_security": "Security",
  "msg_choose_what_data": "Choose what data you share with us",

  // notifications Screen
  "lbl_buy_items": "‘Buy items’",
  "lbl_new": "New",
  "lbl_pay_debt": "‘Pay debt’",
  "lbl_received": "received",
  "lbl_recent": "Recent",
  "lbl_spent": "spent",
  "lbl_you": "You ",
  "msg_28_june_2021_8_32": "28 June 2021, 8.32 PM",
  "msg_29_june_2021_7_14": "29 June 2021, 7.14 PM",
  "msg_rp_100_000_from": " Rp 100.000 from Alexandr Gibson Jogja",
  "msg_rp_210_000_for_pay": " Rp 210.000 for pay Tokosbla ijo mera",
  "msg_you_received_rp": "You received Rp 100.000 from Alexandr Gibson Jogja",
  "msg_you_spent_rp_210_000": "You spent Rp 210.000 for pay Tokosbla ijo mera",

  // Statistics Screen
  "lbl_13_248": "\$ 13.248",
  "lbl_dec": "Dec",
  "lbl_expense_stats": "Expense  Stats",
  "lbl_feb": "Feb",
  "lbl_income_stats": "Income Stats",
  "lbl_jan": "Jan",
  "lbl_nov": "Nov",
  "lbl_oct": "Oct",
  "lbl_oct_feb": "Oct - Feb",
  "lbl_savings_stats": "Savings  Stats",
  "lbl_total_expense": "Total Expense",
  "lbl_total_income": "Total Income",
  "lbl_total_savings": "Total Savings",
  "msg_goal_achievement": "Goal Achievement Stats",

  // Goal Screen
  "lbl_1_00_0002": "1,00,000", "lbl_25_0002": "25,000", "lbl_75_0002": "75,000",
  "lbl_edit": "edit", "lbl_expense": "Expense",

  // Contact Screen
  "lbl_close": "Close",
  "msg_91_8590969173_91":
      "+91 8590969173\n\n+91 9895193693\n\n+91 9567223605\n\n+91 9947686494",
  "msg_aleena_rajan_anagha":
      "Aleena Rajan\n\nAnagha Mathew\n\nAnanthu K M\n\nMuhammed Shamil",

  // Reset Password Screen
  "lbl_change_password2": "Change Password ",
  "lbl_new_password": "New Password",
  "msg_both_password_must": "Both password must match",
  "msg_current_password": "Current Password",

  // Common String
  "lbl_0": "0",
  "lbl_100000": "100000",
  "lbl_25000": "25000",
  "lbl_50000": "50000",
  "lbl_75000": "75000",
  "lbl_contact_us": "Contact Us",
  "lbl_current": "Current",
  "lbl_expenses": "Expenses",
  "lbl_family": "Family",
  "lbl_goal": "Goal",
  "lbl_income": "Income",
  "lbl_jaka": "Jaka",
  "lbl_login_settings": "Login Settings",
  "lbl_next": "Next",
  "lbl_notification": "Notification",
  "lbl_profile": "Profile",
  "lbl_savings": "Savings",
  "lbl_service_center": "Service Center",
  "lbl_settings": "Settings",
  "lbl_statistics": "Statistics",
  "lbl_submit": "Submit",
  "lbl_welcome": "WELCOME",
  "lbl_welcome_back": "Welcome back,",
  "msg_confirm_password": "Confirm Password",
  "msg_privacy_and_security": "Privacy and security",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",

  // Validation Error String
  "err_msg_please_enter_valid_email": "Please enter valid email",
  "err_msg_please_enter_valid_password": "Please enter valid password",
};
