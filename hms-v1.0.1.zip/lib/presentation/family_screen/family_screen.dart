import 'controller/family_controller.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/app_bar/appbar_leading_iconbutton.dart';
import 'package:hms/widgets/app_bar/appbar_trailing_image.dart';
import 'package:hms/widgets/app_bar/custom_app_bar.dart';
import 'package:hms/widgets/custom_icon_button.dart';

class FamilyScreen extends GetWidget<FamilyController> {
  const FamilyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 17.h, vertical: 6.v),
                child: Column(children: [
                  Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                          padding: EdgeInsets.only(left: 115.h),
                          child: Text("lbl_family".tr,
                              style: CustomTextStyles.headlineSmallSemiBold))),
                  SizedBox(height: 50.v),
                  Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                          height: 96.adaptSize,
                          width: 96.adaptSize,
                          margin: EdgeInsets.only(left: 105.h),
                          child: Stack(alignment: Alignment.center, children: [
                            CustomImageView(
                                imagePath: ImageConstant.imgProfilePicture96x96,
                                height: 96.adaptSize,
                                width: 96.adaptSize,
                                radius: BorderRadius.circular(48.h),
                                alignment: Alignment.center),
                            CustomImageView(
                                imagePath: ImageConstant.imgProfilePicture1,
                                height: 96.adaptSize,
                                width: 96.adaptSize,
                                alignment: Alignment.center)
                          ]))),
                  SizedBox(height: 22.v),
                  Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                          padding: EdgeInsets.only(left: 112.h),
                          child: Row(children: [
                            Text("lbl_jaka".tr,
                                style: CustomTextStyles.headlineSmallRubik),
                            CustomImageView(
                                imagePath: ImageConstant.imgEdit,
                                height: 24.adaptSize,
                                width: 24.adaptSize,
                                margin: EdgeInsets.only(left: 8.h, bottom: 4.v))
                          ]))),
                  SizedBox(height: 22.v),
                  Padding(
                      padding: EdgeInsets.only(left: 16.h),
                      child: _buildYourWallet(
                          privacyAndSecurityText: "lbl_family_details".tr)),
                  SizedBox(height: 30.v),
                  Padding(
                      padding: EdgeInsets.only(left: 16.h),
                      child: _buildYourWallet(
                          privacyAndSecurityText:
                              "msg_privacy_and_security".tr)),
                  SizedBox(height: 30.v),
                  Padding(
                      padding: EdgeInsets.only(left: 16.h),
                      child: _buildYourWallet(
                          privacyAndSecurityText: "lbl_login_settings".tr)),
                  SizedBox(height: 30.v),
                  Padding(
                      padding: EdgeInsets.only(left: 16.h),
                      child: _buildYourWallet(
                          privacyAndSecurityText: "lbl_service_center".tr)),
                  SizedBox(height: 93.v),
                  CustomIconButton(
                      height: 64.adaptSize,
                      width: 64.adaptSize,
                      padding: EdgeInsets.all(13.h),
                      decoration: IconButtonStyleHelper.outlineOnErrorContainer,
                      child: CustomImageView(
                          imagePath:
                              ImageConstant.imgThumbsUpOnerrorcontainer)),
                  SizedBox(height: 21.v),
                  Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                          padding: EdgeInsets.only(left: 96.h),
                          child: Text("lbl_delete_family".tr,
                              style: CustomTextStyles.titleMediumRubik18))),
                  SizedBox(height: 5.v)
                ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        leadingWidth: 61.h,
        leading: AppbarLeadingIconbutton(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 23.h, top: 9.v, bottom: 9.v),
            onTap: () {
              onTapArrowLeft();
            }),
        actions: [
          AppbarTrailingImage(
              imagePath: ImageConstant.imgMenuVertical,
              margin: EdgeInsets.fromLTRB(11.h, 12.v, 11.h, 16.v),
              onTap: () {
                menu();
              })
        ]);
  }

  /// Common widget
  Widget _buildYourWallet({required String privacyAndSecurityText}) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Padding(
          padding: EdgeInsets.only(top: 3.v),
          child: Text(privacyAndSecurityText,
              style: theme.textTheme.titleMedium!.copyWith(
                  color: theme.colorScheme.onErrorContainer.withOpacity(1)))),
      CustomImageView(
          imagePath: ImageConstant.imgCocoLineArrow,
          height: 24.adaptSize,
          width: 24.adaptSize)
    ]);
  }

  /// Navigates to the previous screen.
  onTapArrowLeft() {
    Get.back();
  }

  /// Navigates to the menubarScreen when the action is triggered.
  menu() {
    Get.toNamed(
      AppRoutes.menubarScreen,
    );
  }
}
