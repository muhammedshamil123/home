import 'controller/address_controller.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/app_bar/appbar_leading_iconbutton.dart';
import 'package:hms/widgets/app_bar/custom_app_bar.dart';
import 'package:hms/widgets/custom_drop_down.dart';
import 'package:hms/widgets/custom_elevated_button.dart';
import 'package:hms/widgets/custom_text_form_field.dart';

class AddressScreen extends GetWidget<AddressController> {
  const AddressScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            appBar: _buildAppBar(),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 10.h, vertical: 1.v),
                child: Column(children: [
                  Text("lbl_home_address".tr,
                      style: CustomTextStyles.headlineSmallBold),
                  SizedBox(height: 14.v),
                  Container(
                      width: 302.h,
                      margin: EdgeInsets.symmetric(horizontal: 19.h),
                      child: RichText(
                          text: TextSpan(children: [
                            TextSpan(
                                text: "msg_your_home_address2".tr,
                                style: CustomTextStyles.bodyMediumffffffff),
                            TextSpan(text: "              ".tr),
                            TextSpan(
                                text: "lbl_like_directions".tr,
                                style: CustomTextStyles.bodyMediumffffffff)
                          ]),
                          textAlign: TextAlign.left)),
                  SizedBox(height: 66.v),
                  Padding(
                      padding: EdgeInsets.symmetric(horizontal: 5.h),
                      child: CustomDropDown(
                          icon: Container(
                              margin: EdgeInsets.only(left: 30.h, right: 7.h),
                              child: CustomImageView(
                                  imagePath: ImageConstant.imgSortDown,
                                  height: 24.adaptSize,
                                  width: 24.adaptSize)),
                          hintText: "lbl_country".tr,
                          items: controller
                              .addressModelObj.value.dropdownItemList!.value,
                          onChanged: (value) {
                            controller.onSelected(value);
                          })),
                  SizedBox(height: 48.v),
                  _buildHomeAddressEditText1(),
                  SizedBox(height: 51.v),
                  _buildYourHomeAddressEditText2(),
                  SizedBox(height: 45.v),
                  _buildCityEditText(),
                  SizedBox(height: 47.v),
                  _buildPostcodeValueEditText(),
                  Spacer(),
                  SizedBox(height: 28.v),
                  _buildFortyEight()
                ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        leadingWidth: double.maxFinite,
        leading: AppbarLeadingIconbutton(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.fromLTRB(15.h, 9.v, 307.h, 9.v),
            onTap: () {
              onTapArrowLeft();
            }));
  }

  /// Section Widget
  Widget _buildHomeAddressEditText1() {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 5.h),
        child: CustomTextFormField(
            controller: controller.homeAddressEditText1Controller,
            hintText: "lbl_address_line_1".tr,
            contentPadding: EdgeInsets.symmetric(horizontal: 6.h),
            borderDecoration:
                TextFormFieldStyleHelper.underLineOnErrorContainer,
            filled: false));
  }

  /// Section Widget
  Widget _buildYourHomeAddressEditText2() {
    return Padding(
        padding: EdgeInsets.only(left: 8.h, right: 2.h),
        child: CustomTextFormField(
            controller: controller.yourHomeAddressEditText2Controller,
            hintText: "lbl_address_line_2".tr,
            contentPadding: EdgeInsets.symmetric(horizontal: 3.h),
            borderDecoration:
                TextFormFieldStyleHelper.underLineOnErrorContainer,
            filled: false));
  }

  /// Section Widget
  Widget _buildCityEditText() {
    return Padding(
        padding: EdgeInsets.only(left: 8.h, right: 2.h),
        child: CustomTextFormField(
            controller: controller.cityEditTextController,
            hintText: "lbl_town_city".tr,
            contentPadding: EdgeInsets.symmetric(horizontal: 1.h),
            borderDecoration:
                TextFormFieldStyleHelper.underLineOnErrorContainer,
            filled: false));
  }

  /// Section Widget
  Widget _buildPostcodeValueEditText() {
    return Padding(
        padding: EdgeInsets.only(left: 8.h, right: 2.h),
        child: CustomTextFormField(
            controller: controller.postcodeValueEditTextController,
            hintText: "lbl_postcode".tr,
            textInputAction: TextInputAction.done,
            suffix: Container(
                margin: EdgeInsets.only(left: 30.h, top: 3.v, bottom: 7.v),
                child: CustomImageView(
                    imagePath: ImageConstant.imgBoxImportant,
                    height: 16.v,
                    width: 19.h)),
            suffixConstraints: BoxConstraints(maxHeight: 27.v),
            contentPadding: EdgeInsets.only(left: 1.h),
            borderDecoration:
                TextFormFieldStyleHelper.underLineOnErrorContainer,
            filled: false));
  }

  /// Section Widget
  Widget _buildNextButton() {
    return CustomElevatedButton(
        width: 119.h,
        text: "lbl_next".tr,
        onPressed: () {
          onTapNextButton();
        });
  }

  /// Section Widget
  Widget _buildFortyEight() {
    return Padding(
        padding: EdgeInsets.only(left: 15.h),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          GestureDetector(
              onTap: () {
                onTapTxtSkip();
              },
              child: Padding(
                  padding: EdgeInsets.only(top: 15.v, bottom: 11.v),
                  child: Text("lbl_skip".tr,
                      style: CustomTextStyles.titleLargeIndigoA200))),
          _buildNextButton()
        ]));
  }

  /// Navigates to the previous screen.
  onTapArrowLeft() {
    Get.back();
  }

  /// Navigates to the mainContainerScreen when the action is triggered.
  onTapTxtSkip() {
    Get.toNamed(
      AppRoutes.mainContainerScreen,
    );
  }

  /// Navigates to the mainContainerScreen when the action is triggered.
  onTapNextButton() {
    Get.toNamed(
      AppRoutes.mainContainerScreen,
    );
  }
}
