import 'package:hms/core/app_export.dart';
import 'package:hms/presentation/address_screen/models/address_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the AddressScreen.
///
/// This class manages the state of the AddressScreen, including the
/// current addressModelObj
class AddressController extends GetxController {
  TextEditingController homeAddressEditText1Controller =
      TextEditingController();

  TextEditingController yourHomeAddressEditText2Controller =
      TextEditingController();

  TextEditingController cityEditTextController = TextEditingController();

  TextEditingController postcodeValueEditTextController =
      TextEditingController();

  Rx<AddressModel> addressModelObj = AddressModel().obs;

  SelectionPopupModel? selectedDropDownValue;

  @override
  void onClose() {
    super.onClose();
    homeAddressEditText1Controller.dispose();
    yourHomeAddressEditText2Controller.dispose();
    cityEditTextController.dispose();
    postcodeValueEditTextController.dispose();
  }

  onSelected(dynamic value) {
    for (var element in addressModelObj.value.dropdownItemList.value) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    }
    addressModelObj.value.dropdownItemList.refresh();
  }
}
