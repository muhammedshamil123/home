import 'controller/reset_password_controller.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/custom_elevated_button.dart';
import 'package:hms/widgets/custom_text_form_field.dart';

class ResetPasswordScreen extends GetWidget<ResetPasswordController> {
  const ResetPasswordScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            backgroundColor: appTheme.blueGray200,
            body: Container(
                width: 339.h,
                padding: EdgeInsets.symmetric(horizontal: 30.h, vertical: 5.v),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 18.v),
                      Align(
                          alignment: Alignment.center,
                          child: Text("lbl_change_password2".tr,
                              style: CustomTextStyles.titleMediumPoppins)),
                      SizedBox(height: 12.v),
                      Padding(
                          padding: EdgeInsets.only(left: 4.h),
                          child: Text("msg_current_password".tr,
                              style:
                                  CustomTextStyles.bodySmallPoppinsBlack900)),
                      _buildPasswordField(),
                      SizedBox(height: 6.v),
                      Padding(
                          padding: EdgeInsets.only(left: 4.h),
                          child: Text("lbl_new_password".tr,
                              style:
                                  CustomTextStyles.bodySmallPoppinsBlack900)),
                      _buildNewPasswordField(),
                      SizedBox(height: 4.v),
                      Padding(
                          padding: EdgeInsets.only(left: 5.h),
                          child: Text("msg_confirm_password".tr,
                              style:
                                  CustomTextStyles.bodySmallPoppinsBlack900)),
                      SizedBox(height: 2.v),
                      _buildConfirmPasswordField(),
                      SizedBox(height: 1.v),
                      Padding(
                          padding: EdgeInsets.only(left: 4.h),
                          child: Text("msg_both_password_must".tr,
                              style:
                                  CustomTextStyles.bodySmallPoppinsBlack90010))
                    ])),
            bottomNavigationBar: _buildSubmitButton()));
  }

  /// Section Widget
  Widget _buildPasswordField() {
    return Padding(
        padding: EdgeInsets.only(left: 5.h),
        child: CustomTextFormField(
            controller: controller.passwordFieldController,
            prefix: Container(
                margin: EdgeInsets.fromLTRB(7.h, 10.v, 30.h, 9.v),
                child: CustomImageView(
                    imagePath: ImageConstant.imgInterfaceEssentialLockPassword,
                    height: 22.adaptSize,
                    width: 22.adaptSize)),
            prefixConstraints: BoxConstraints(maxHeight: 41.v),
            obscureText: true,
            borderDecoration: TextFormFieldStyleHelper.fillBlueGray,
            fillColor: appTheme.blueGray10001));
  }

  /// Section Widget
  Widget _buildNewPasswordField() {
    return Padding(
        padding: EdgeInsets.only(left: 5.h),
        child: Obx(() => CustomTextFormField(
            controller: controller.newPasswordFieldController,
            prefix: Container(
                margin: EdgeInsets.fromLTRB(7.h, 10.v, 30.h, 9.v),
                child: CustomImageView(
                    imagePath: ImageConstant.imgLocation,
                    height: 22.adaptSize,
                    width: 22.adaptSize)),
            prefixConstraints: BoxConstraints(maxHeight: 41.v),
            suffix: InkWell(
                onTap: () {
                  controller.isShowPassword.value =
                      !controller.isShowPassword.value;
                },
                child: Container(
                    margin: EdgeInsets.fromLTRB(30.h, 10.v, 7.h, 8.v),
                    child: CustomImageView(
                        imagePath: ImageConstant.imgEye,
                        height: 22.adaptSize,
                        width: 22.adaptSize))),
            suffixConstraints: BoxConstraints(maxHeight: 41.v),
            obscureText: controller.isShowPassword.value,
            borderDecoration: TextFormFieldStyleHelper.fillBlueGray,
            fillColor: appTheme.blueGray10001)));
  }

  /// Section Widget
  Widget _buildConfirmPasswordField() {
    return Padding(
        padding: EdgeInsets.only(left: 3.h),
        child: CustomTextFormField(
            controller: controller.confirmPasswordFieldController,
            textInputAction: TextInputAction.done,
            prefix: Container(
                margin: EdgeInsets.fromLTRB(9.h, 10.v, 30.h, 9.v),
                child: CustomImageView(
                    imagePath: ImageConstant.imgLocation,
                    height: 22.adaptSize,
                    width: 22.adaptSize)),
            prefixConstraints: BoxConstraints(maxHeight: 41.v),
            obscureText: true,
            borderDecoration: TextFormFieldStyleHelper.fillBlueGray,
            fillColor: appTheme.blueGray10001));
  }

  /// Section Widget
  Widget _buildSubmitButton() {
    return CustomElevatedButton(
        height: 37.v,
        width: 135.h,
        text: "lbl_submit".tr,
        margin: EdgeInsets.only(left: 102.h, right: 102.h, bottom: 32.v),
        buttonStyle: CustomButtonStyles.fillBlueGray,
        buttonTextStyle: CustomTextStyles.titleSmallBlack900,
        onPressed: () {
          onBackPressed();
        });
  }

  /// Navigates to the previous screen.
  onBackPressed() {
    Get.back();
  }
}
