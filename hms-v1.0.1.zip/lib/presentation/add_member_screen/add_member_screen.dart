import 'controller/add_member_controller.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/custom_outlined_button.dart';
import 'package:hms/widgets/custom_text_form_field.dart';

class AddMemberScreen extends GetWidget<AddMemberController> {
  const AddMemberScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            resizeToAvoidBottomInset: false,
            body: Container(
                width: SizeUtils.width,
                height: SizeUtils.height,
                decoration: BoxDecoration(
                    border: Border.all(color: appTheme.black900, width: 1.h),
                    gradient: LinearGradient(
                        begin: Alignment(0.5, 0),
                        end: Alignment(0.5, 1),
                        colors: [
                          appTheme.indigo900,
                          theme.colorScheme.primaryContainer
                        ])),
                child: Container(
                    width: double.maxFinite,
                    padding:
                        EdgeInsets.symmetric(horizontal: 31.h, vertical: 52.v),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(height: 4.v),
                          Padding(
                              padding: EdgeInsets.only(left: 1.h),
                              child: Text("lbl_member_name".tr,
                                  style: theme.textTheme.bodySmall)),
                          SizedBox(height: 7.v),
                          _buildMemberName(),
                          SizedBox(height: 25.v),
                          Padding(
                              padding: EdgeInsets.only(left: 1.h),
                              child: Text("lbl_member_email".tr,
                                  style: theme.textTheme.bodySmall)),
                          SizedBox(height: 6.v),
                          _buildMemberEmail(),
                          SizedBox(height: 26.v),
                          Padding(
                              padding: EdgeInsets.only(left: 1.h),
                              child: Text("lbl_role".tr,
                                  style: theme.textTheme.bodySmall)),
                          SizedBox(height: 5.v),
                          _buildRole(),
                          SizedBox(height: 47.v),
                          _buildSubmit()
                        ])))));
  }

  /// Section Widget
  Widget _buildMemberName() {
    return Padding(
        padding: EdgeInsets.only(left: 1.h),
        child: CustomTextFormField(
            controller: controller.memberNameController,
            borderDecoration:
                TextFormFieldStyleHelper.outlinePrimaryContainerTL15,
            fillColor: theme.colorScheme.onErrorContainer.withOpacity(1)));
  }

  /// Section Widget
  Widget _buildMemberEmail() {
    return Padding(
        padding: EdgeInsets.only(left: 1.h),
        child: CustomTextFormField(
            controller: controller.memberEmailController,
            borderDecoration:
                TextFormFieldStyleHelper.outlinePrimaryContainerTL15,
            fillColor: theme.colorScheme.onErrorContainer.withOpacity(1)));
  }

  /// Section Widget
  Widget _buildRole() {
    return Padding(
        padding: EdgeInsets.only(left: 1.h),
        child: CustomTextFormField(
            controller: controller.roleController,
            textInputAction: TextInputAction.done,
            borderDecoration:
                TextFormFieldStyleHelper.outlinePrimaryContainerTL15,
            fillColor: theme.colorScheme.onErrorContainer.withOpacity(1)));
  }

  /// Section Widget
  Widget _buildSubmit() {
    return CustomOutlinedButton(
        height: 54.v,
        width: 178.h,
        text: "lbl_submit".tr,
        margin: EdgeInsets.only(right: 51.h),
        buttonStyle: CustomButtonStyles.outlinePrimary,
        onPressed: () {
          onBackPressed();
        },
        alignment: Alignment.centerRight);
  }

  /// Navigates to the previous screen.
  onBackPressed() {
    Get.back();
  }
}
