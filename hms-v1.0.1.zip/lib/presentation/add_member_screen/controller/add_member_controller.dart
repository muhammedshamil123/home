import 'package:hms/core/app_export.dart';
import 'package:hms/presentation/add_member_screen/models/add_member_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the AddMemberScreen.
///
/// This class manages the state of the AddMemberScreen, including the
/// current addMemberModelObj
class AddMemberController extends GetxController {
  TextEditingController memberNameController = TextEditingController();

  TextEditingController memberEmailController = TextEditingController();

  TextEditingController roleController = TextEditingController();

  Rx<AddMemberModel> addMemberModelObj = AddMemberModel().obs;

  @override
  void onClose() {
    super.onClose();
    memberNameController.dispose();
    memberEmailController.dispose();
    roleController.dispose();
  }
}
