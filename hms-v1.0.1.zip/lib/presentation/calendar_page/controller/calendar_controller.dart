import 'package:hms/core/app_export.dart';
import 'package:hms/presentation/calendar_page/models/calendar_model.dart';

/// A controller class for the CalendarPage.
///
/// This class manages the state of the CalendarPage, including the
/// current calendarModelObj
class CalendarController extends GetxController {
  CalendarController(this.calendarModelObj);

  Rx<CalendarModel> calendarModelObj;
}
