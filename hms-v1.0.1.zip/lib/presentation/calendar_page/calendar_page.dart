import 'controller/calendar_controller.dart';
import 'models/calendar_model.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/custom_icon_button.dart';

// ignore_for_file: must_be_immutable
class CalendarPage extends StatelessWidget {
  CalendarPage({Key? key}) : super(key: key);

  CalendarController controller =
      Get.put(CalendarController(CalendarModel().obs));

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                width: double.maxFinite,
                decoration: AppDecoration.fillPrimaryContainer,
                child:
                    Column(children: [_buildProfilePictureRow(), Spacer()]))));
  }

  /// Section Widget
  Widget _buildProfilePictureRow() {
    return Container(
        width: double.maxFinite,
        padding: EdgeInsets.symmetric(horizontal: 10.h, vertical: 24.v),
        decoration: AppDecoration.fillPrimaryContainer
            .copyWith(borderRadius: BorderRadiusStyle.customBorderTL20),
        child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomImageView(
                  imagePath: ImageConstant.imgProfilePicture,
                  height: 47.v,
                  width: 51.h,
                  radius: BorderRadius.circular(25.h),
                  margin: EdgeInsets.only(left: 17.h, bottom: 1.v),
                  onTap: () {
                    onTapImgProfilePicture();
                  }),
              Padding(
                  padding: EdgeInsets.only(left: 8.h, bottom: 9.v),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("lbl_welcome_back".tr,
                            style:
                                CustomTextStyles.bodySmallPoppinsBluegray40001),
                        SizedBox(height: 3.v),
                        Text("lbl_jaka".tr,
                            style: CustomTextStyles.titleMediumRubik)
                      ])),
              Spacer(),
              Padding(
                  padding: EdgeInsets.only(top: 7.v, bottom: 14.v),
                  child: CustomIconButton(
                      height: 28.v,
                      width: 39.h,
                      onTap: () {
                        menu();
                      },
                      child: CustomImageView(
                          imagePath: ImageConstant.imgMenuVertical)))
            ]));
  }

  /// Navigates to the profileScreen when the action is triggered.
  onTapImgProfilePicture() {
    Get.toNamed(
      AppRoutes.profileScreen,
    );
  }

  /// Navigates to the menubarScreen when the action is triggered.
  menu() {
    Get.toNamed(
      AppRoutes.menubarScreen,
    );
  }
}
