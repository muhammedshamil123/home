import '../controller/create_home_controller.dart';
import 'package:get/get.dart';

/// A binding class for the CreateHomeScreen.
///
/// This class ensures that the CreateHomeController is created when the
/// CreateHomeScreen is first loaded.
class CreateHomeBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => CreateHomeController());
  }
}
