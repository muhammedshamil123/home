import 'package:hms/core/app_export.dart';
import 'package:hms/presentation/create_home_screen/models/create_home_model.dart';

/// A controller class for the CreateHomeScreen.
///
/// This class manages the state of the CreateHomeScreen, including the
/// current createHomeModelObj
class CreateHomeController extends GetxController {
  Rx<CreateHomeModel> createHomeModelObj = CreateHomeModel().obs;
}
