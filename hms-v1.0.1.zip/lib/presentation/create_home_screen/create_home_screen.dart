import 'controller/create_home_controller.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/custom_outlined_button.dart';

class CreateHomeScreen extends GetWidget<CreateHomeController> {
  const CreateHomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  SizedBox(height: 49.v),
                  Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                          padding: EdgeInsets.only(left: 13.h),
                          child: Text("msg_create_your_home".tr,
                              style: CustomTextStyles.headlineSmallExtraBold))),
                  Spacer(),
                  Container(
                      width: 336.h,
                      margin: EdgeInsets.symmetric(horizontal: 12.h),
                      child: Text("msg_create_a_home_to".tr,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: theme.textTheme.bodyLarge)),
                  SizedBox(height: 96.v),
                  SizedBox(
                      height: 450.v,
                      width: double.maxFinite,
                      child: Stack(alignment: Alignment.bottomLeft, children: [
                        CustomImageView(
                            imagePath: ImageConstant.imgCommunication,
                            height: 600.v,
                            width: 360.h,
                            alignment: Alignment.center),
                        CustomOutlinedButton(
                            height: 58.v,
                            width: 273.h,
                            text: "lbl_create_home".tr,
                            margin: EdgeInsets.only(left: 31.h, bottom: 63.v),
                            leftIcon: Container(
                                margin: EdgeInsets.only(right: 30.h),
                                child: CustomImageView(
                                    imagePath: ImageConstant.imgAdd,
                                    height: 38.v,
                                    width: 31.h)),
                            buttonStyle: CustomButtonStyles.outlineGrayTL20,
                            onPressed: () {
                              onTapCreateHome();
                            },
                            alignment: Alignment.bottomLeft)
                      ]))
                ]))));
  }

  /// Navigates to the nextScreen when the action is triggered.
  onTapCreateHome() {
    Get.toNamed(
      AppRoutes.nextScreen,
    );
  }
}
