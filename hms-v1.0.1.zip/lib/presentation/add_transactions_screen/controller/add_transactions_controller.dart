import 'package:hms/core/app_export.dart';
import 'package:hms/presentation/add_transactions_screen/models/add_transactions_model.dart';

/// A controller class for the AddTransactionsScreen.
///
/// This class manages the state of the AddTransactionsScreen, including the
/// current addTransactionsModelObj
class AddTransactionsController extends GetxController {
  Rx<AddTransactionsModel> addTransactionsModelObj = AddTransactionsModel().obs;

  SelectionPopupModel? selectedDropDownValue;

  onSelected(dynamic value) {
    for (var element in addTransactionsModelObj.value.dropdownItemList.value) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    }
    addTransactionsModelObj.value.dropdownItemList.refresh();
  }
}
