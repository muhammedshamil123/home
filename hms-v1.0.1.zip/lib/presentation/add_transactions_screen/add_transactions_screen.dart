import 'controller/add_transactions_controller.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/app_bar/appbar_leading_iconbutton.dart';
import 'package:hms/widgets/app_bar/appbar_subtitle_one.dart';
import 'package:hms/widgets/app_bar/appbar_trailing_image.dart';
import 'package:hms/widgets/app_bar/custom_app_bar.dart';
import 'package:hms/widgets/custom_drop_down.dart';
import 'package:hms/widgets/custom_elevated_button.dart';

class AddTransactionsScreen extends GetWidget<AddTransactionsController> {
  const AddTransactionsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.only(left: 24.h, top: 64.v, right: 24.h),
                child: Column(children: [
                  _buildFiftyOne(),
                  SizedBox(height: 28.v),
                  _buildCategory(),
                  SizedBox(height: 27.v),
                  _buildDate(),
                  SizedBox(height: 26.v),
                  _buildDate1(),
                  SizedBox(height: 27.v),
                  _buildDate2(),
                  SizedBox(height: 28.v),
                  _buildDate3(),
                  SizedBox(height: 5.v)
                ])),
            bottomNavigationBar: _buildSaveClose()));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        leadingWidth: 51.h,
        leading: AppbarLeadingIconbutton(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 13.h, top: 9.v, bottom: 9.v),
            onTap: () {
              onTapArrowLeft();
            }),
        centerTitle: true,
        title: AppbarSubtitleOne(text: "lbl_add_transaction".tr),
        actions: [
          AppbarTrailingImage(
              imagePath: ImageConstant.imgMenuVertical,
              margin: EdgeInsets.fromLTRB(10.h, 13.v, 10.h, 15.v))
        ]);
  }

  /// Section Widget
  Widget _buildFiftyOne() {
    return Padding(
        padding: EdgeInsets.only(left: 8.h),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text("lbl_type".tr, style: CustomTextStyles.titleLargePrimary),
          Container(
              height: 20.v,
              width: 151.h,
              margin: EdgeInsets.only(top: 3.v),
              child: Container())
        ]));
  }

  /// Section Widget
  Widget _buildCategory() {
    return Padding(
        padding: EdgeInsets.only(left: 8.h),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text("lbl_category".tr, style: CustomTextStyles.titleLargePrimary),
          Padding(
              padding: EdgeInsets.only(bottom: 4.v),
              child: CustomDropDown(
                  width: 151.h,
                  icon: Container(
                      margin: EdgeInsets.only(left: 30.h),
                      child: CustomImageView(
                          imagePath: ImageConstant.imgMenuVertical,
                          height: 20.adaptSize,
                          width: 20.adaptSize)),
                  items: controller
                      .addTransactionsModelObj.value.dropdownItemList!.value,
                  borderDecoration: DropDownStyleHelper.underLineBlueGray,
                  onChanged: (value) {
                    controller.onSelected(value);
                  }))
        ]));
  }

  /// Section Widget
  Widget _buildDate() {
    return Padding(
        padding: EdgeInsets.only(left: 8.h),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text("lbl_description".tr, style: CustomTextStyles.titleLargePrimary),
          Container(
              width: 151.h,
              margin: EdgeInsets.only(top: 21.v, bottom: 2.v),
              decoration: BoxDecoration(color: appTheme.blueGray400))
        ]));
  }

  /// Section Widget
  Widget _buildDate1() {
    return Padding(
        padding: EdgeInsets.only(left: 8.h),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text("lbl_date".tr, style: CustomTextStyles.titleLargePrimary),
          Container(
              width: 151.h,
              margin: EdgeInsets.only(top: 24.v),
              decoration: BoxDecoration(color: appTheme.blueGray400))
        ]));
  }

  /// Section Widget
  Widget _buildDate2() {
    return Padding(
        padding: EdgeInsets.only(left: 8.h),
        child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("lbl_time".tr, style: CustomTextStyles.titleLargePrimary)
            ]));
  }

  /// Section Widget
  Widget _buildDate3() {
    return Padding(
        padding: EdgeInsets.only(left: 8.h),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text("lbl_amount".tr,
              style: CustomTextStyles.titleLargePrimaryRegular),
          Padding(
              padding: EdgeInsets.only(top: 24.v),
              child: SizedBox(width: 151.h, child: Divider()))
        ]));
  }

  /// Section Widget
  Widget _buildSaveClose() {
    return CustomElevatedButton(
        height: 58.v,
        text: "lbl_save_close".tr,
        buttonStyle: CustomButtonStyles.fillBlue,
        buttonTextStyle: theme.textTheme.bodyLarge!);
  }

  /// Navigates to the previous screen.
  onTapArrowLeft() {
    Get.back();
  }
}
