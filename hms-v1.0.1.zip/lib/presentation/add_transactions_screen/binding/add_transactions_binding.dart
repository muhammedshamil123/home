import '../controller/add_transactions_controller.dart';
import 'package:get/get.dart';

/// A binding class for the AddTransactionsScreen.
///
/// This class ensures that the AddTransactionsController is created when the
/// AddTransactionsScreen is first loaded.
class AddTransactionsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => AddTransactionsController());
  }
}
