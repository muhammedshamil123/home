import 'controller/settings_controller.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/app_bar/appbar_leading_iconbutton.dart';
import 'package:hms/widgets/app_bar/appbar_subtitle_three.dart';
import 'package:hms/widgets/app_bar/appbar_trailing_image.dart';
import 'package:hms/widgets/app_bar/custom_app_bar.dart';

class SettingsScreen extends GetWidget<SettingsController> {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 12.h, vertical: 36.v),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                          padding: EdgeInsets.only(left: 1.h),
                          child: Text("lbl_general".tr,
                              style:
                                  CustomTextStyles.bodyMediumPoppinsGray500)),
                      SizedBox(height: 29.v),
                      _buildLanguageRow(),
                      SizedBox(height: 10.v),
                      Divider(color: appTheme.blueGray900, indent: 1.h),
                      SizedBox(height: 21.v),
                      Padding(
                          padding: EdgeInsets.only(left: 1.h),
                          child: _buildContactUsRow(
                              contactText: "lbl_my_profile".tr)),
                      SizedBox(height: 10.v),
                      Divider(color: appTheme.blueGray900, indent: 1.h),
                      SizedBox(height: 21.v),
                      Padding(
                          padding: EdgeInsets.only(left: 1.h),
                          child: _buildContactUsRow(
                              contactText: "lbl_contact_us".tr)),
                      SizedBox(height: 10.v),
                      Divider(color: appTheme.blueGray900, indent: 1.h),
                      SizedBox(height: 27.v),
                      Padding(
                          padding: EdgeInsets.only(left: 1.h),
                          child: Text("lbl_security".tr,
                              style:
                                  CustomTextStyles.bodyMediumPoppinsGray500)),
                      SizedBox(height: 28.v),
                      Padding(
                          padding: EdgeInsets.only(left: 1.h),
                          child: _buildContactUsRow(
                              contactText: "lbl_change_password".tr,
                              onTapContactUsRow: () {
                                onTapContactUsRow();
                              })),
                      SizedBox(height: 10.v),
                      Divider(color: appTheme.blueGray900, indent: 1.h),
                      SizedBox(height: 21.v),
                      Padding(
                          padding: EdgeInsets.only(left: 1.h),
                          child: _buildContactUsRow(
                              contactText: "lbl_privacy_policy".tr)),
                      SizedBox(height: 10.v),
                      Divider(color: appTheme.blueGray900, indent: 1.h),
                      SizedBox(height: 11.v),
                      Padding(
                          padding: EdgeInsets.only(left: 1.h),
                          child: Text("msg_choose_what_data".tr,
                              style: CustomTextStyles
                                  .bodySmallPoppinsBluegray40001)),
                      SizedBox(height: 5.v)
                    ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        leadingWidth: 54.h,
        leading: AppbarLeadingIconbutton(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 16.h, top: 5.v, bottom: 12.v),
            onTap: () {
              onTapArrowLeft();
            }),
        centerTitle: true,
        title: AppbarSubtitleThree(text: "lbl_settings".tr),
        actions: [
          AppbarTrailingImage(
              imagePath: ImageConstant.imgMenuVertical,
              margin: EdgeInsets.fromLTRB(21.h, 8.v, 21.h, 19.v),
              onTap: () {
                menu();
              })
        ]);
  }

  /// Section Widget
  Widget _buildLanguageRow() {
    return Padding(
        padding: EdgeInsets.only(left: 1.h),
        child: Row(children: [
          Padding(
              padding: EdgeInsets.only(top: 2.v),
              child:
                  Text("lbl_language".tr, style: theme.textTheme.titleSmall)),
          Spacer(),
          Padding(
              padding: EdgeInsets.only(top: 2.v),
              child: Text("lbl_english".tr,
                  style: CustomTextStyles.bodyMediumPoppinsBluegray40001)),
          CustomImageView(
              imagePath: ImageConstant.imgArrowRightBlueGray40001,
              height: 24.adaptSize,
              width: 24.adaptSize,
              margin: EdgeInsets.only(left: 16.h))
        ]));
  }

  /// Common widget
  Widget _buildContactUsRow({
    required String contactText,
    Function? onTapContactUsRow,
  }) {
    return GestureDetector(
        onTap: () {
          onTapContactUsRow!.call();
        },
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Padding(
              padding: EdgeInsets.only(bottom: 2.v),
              child: Text(contactText,
                  style: theme.textTheme.titleSmall!.copyWith(
                      color:
                          theme.colorScheme.onErrorContainer.withOpacity(1)))),
          CustomImageView(
              imagePath: ImageConstant.imgArrowRightBlueGray40001,
              height: 24.adaptSize,
              width: 24.adaptSize)
        ]));
  }

  /// Navigates to the previous screen.
  onTapArrowLeft() {
    Get.back();
  }

  /// Navigates to the menubarScreen when the action is triggered.
  menu() {
    Get.toNamed(
      AppRoutes.menubarScreen,
    );
  }

  /// Navigates to the resetPasswordScreen when the action is triggered.
  onTapContactUsRow() {
    Get.toNamed(
      AppRoutes.resetPasswordScreen,
    );
  }
}
