import 'controller/loginpage_controller.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/core/utils/validation_functions.dart';
import 'package:hms/widgets/custom_elevated_button.dart';
import 'package:hms/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class LoginpageScreen extends GetWidget<LoginpageController> {
  LoginpageScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SizedBox(
                width: SizeUtils.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).viewInsets.bottom),
                    child: Form(
                        key: _formKey,
                        child: Container(
                            width: double.maxFinite,
                            padding: EdgeInsets.symmetric(
                                horizontal: 5.h, vertical: 30.v),
                            child: Column(children: [
                              _buildWelcomeSection(),
                              SizedBox(height: 7.v),
                              Padding(
                                  padding:
                                      EdgeInsets.only(left: 4.h, right: 13.h),
                                  child: CustomTextFormField(
                                      controller: controller.emailController,
                                      hintText: "lbl_email".tr,
                                      textInputType: TextInputType.emailAddress,
                                      prefix: Container(
                                          margin: EdgeInsets.fromLTRB(
                                              18.h, 23.v, 13.h, 25.v),
                                          child: CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgCheckmark,
                                              height: 24.adaptSize,
                                              width: 24.adaptSize)),
                                      prefixConstraints:
                                          BoxConstraints(maxHeight: 72.v),
                                      validator: (value) {
                                        if (value == null ||
                                            (!isValidEmail(value,
                                                isRequired: true))) {
                                          return "err_msg_please_enter_valid_email"
                                              .tr;
                                        }
                                        return null;
                                      },
                                      borderDecoration: TextFormFieldStyleHelper
                                          .fillOnErrorContainer,
                                      fillColor: theme
                                          .colorScheme.onErrorContainer
                                          .withOpacity(1))),
                              SizedBox(height: 26.v),
                              Padding(
                                  padding:
                                      EdgeInsets.only(left: 4.h, right: 13.h),
                                  child: CustomTextFormField(
                                      controller: controller.passwordController,
                                      hintText: "lbl_password".tr,
                                      textInputAction: TextInputAction.done,
                                      textInputType:
                                          TextInputType.visiblePassword,
                                      prefix: Container(
                                          margin: EdgeInsets.fromLTRB(
                                              20.h, 22.v, 11.h, 26.v),
                                          child: CustomImageView(
                                              imagePath: ImageConstant.imgUser,
                                              height: 24.adaptSize,
                                              width: 24.adaptSize)),
                                      prefixConstraints:
                                          BoxConstraints(maxHeight: 72.v),
                                      validator: (value) {
                                        if (value == null ||
                                            (!isValidPassword(value,
                                                isRequired: true))) {
                                          return "err_msg_please_enter_valid_password"
                                              .tr;
                                        }
                                        return null;
                                      },
                                      obscureText: true,
                                      borderDecoration: TextFormFieldStyleHelper
                                          .fillOnErrorContainer,
                                      fillColor: theme
                                          .colorScheme.onErrorContainer
                                          .withOpacity(1))),
                              SizedBox(height: 36.v),
                              CustomElevatedButton(
                                  height: 76.v,
                                  text: "lbl_login".tr,
                                  margin: EdgeInsets.symmetric(horizontal: 4.h),
                                  buttonStyle: CustomButtonStyles.outlineBlack,
                                  buttonTextStyle:
                                      CustomTextStyles.headlineSmallBold,
                                  onPressed: () {
                                    onTapLogin();
                                  }),
                              SizedBox(height: 18.v),
                              Text("msg_don_t_have_an_account".tr,
                                  style: CustomTextStyles.titleLargeRegular),
                              SizedBox(height: 5.v),
                              GestureDetector(
                                  onTap: () {
                                    onTapTxtSignUp();
                                  },
                                  child: Text("lbl_sign_up2".tr,
                                      style: CustomTextStyles.bodyLargeBlue600))
                            ])))))));
  }

  /// Section Widget
  Widget _buildWelcomeSection() {
    return SizedBox(
        height: 372.v,
        width: 350.h,
        child: Stack(alignment: Alignment.bottomCenter, children: [
          Align(
              alignment: Alignment.topCenter,
              child:
                  Text("lbl_welcome".tr, style: theme.textTheme.displayMedium)),
          CustomImageView(
              imagePath: ImageConstant.imgWorkflowWoman,
              height: 350.adaptSize,
              width: 350.adaptSize,
              alignment: Alignment.bottomCenter)
        ]));
  }

  /// Navigates to the mainContainerScreen when the action is triggered.
  onTapLogin() {
    Get.toNamed(
      AppRoutes.mainContainerScreen,
    );
  }

  /// Navigates to the signupScreen when the action is triggered.
  onTapTxtSignUp() {
    Get.toNamed(
      AppRoutes.signupScreen,
    );
  }
}
