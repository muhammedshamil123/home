import 'controller/menubar_controller.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/app_bar/appbar_leading_iconbutton_one.dart';
import 'package:hms/widgets/app_bar/appbar_title.dart';
import 'package:hms/widgets/app_bar/custom_app_bar.dart';
import 'package:hms/widgets/custom_icon_button.dart';

class MenubarScreen extends GetWidget<MenubarController> {
  const MenubarScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: appTheme.indigoA20001,
            appBar: _buildAppBar(),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(vertical: 30.v),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 34.v),
                      Padding(
                          padding: EdgeInsets.only(left: 19.h, right: 114.h),
                          child: Row(children: [
                            CustomIconButton(
                                height: 44.adaptSize,
                                width: 44.adaptSize,
                                padding: EdgeInsets.all(10.h),
                                decoration:
                                    IconButtonStyleHelper.outlineBlueGray,
                                child: CustomImageView(
                                    imagePath: ImageConstant.imgLock)),
                            Padding(
                                padding: EdgeInsets.only(
                                    left: 21.h, top: 9.v, bottom: 10.v),
                                child: Text("lbl_profile".tr,
                                    style: theme.textTheme.titleLarge)),
                            Spacer(),
                            CustomImageView(
                                imagePath: ImageConstant.imgCocoLineArrow,
                                height: 23.v,
                                width: 21.h,
                                margin: EdgeInsets.only(top: 16.v, bottom: 3.v))
                          ])),
                      SizedBox(height: 9.v),
                      GestureDetector(
                          onTap: () {
                            onTapSixtyEight();
                          },
                          child: Padding(
                              padding:
                                  EdgeInsets.only(left: 20.h, right: 114.h),
                              child: Row(children: [
                                CustomIconButton(
                                    height: 44.adaptSize,
                                    width: 44.adaptSize,
                                    padding: EdgeInsets.all(8.h),
                                    decoration:
                                        IconButtonStyleHelper.outlineBlueGray,
                                    child: CustomImageView(
                                        imagePath: ImageConstant
                                            .imgUserPrimarycontainer)),
                                Padding(
                                    padding: EdgeInsets.only(
                                        left: 20.h, top: 9.v, bottom: 9.v),
                                    child: Text("lbl_statistics".tr,
                                        style: theme.textTheme.titleLarge)),
                                Spacer(),
                                CustomImageView(
                                    imagePath: ImageConstant.imgCocoLineArrow,
                                    height: 23.v,
                                    width: 21.h,
                                    margin: EdgeInsets.symmetric(vertical: 9.v))
                              ]))),
                      SizedBox(height: 9.v),
                      Padding(
                          padding: EdgeInsets.only(left: 21.h, right: 114.h),
                          child: _buildGoalSetup(
                              goalSetupText: "lbl_family".tr,
                              onTapGoalSetup: () {
                                onTapGoalSetup();
                              })),
                      SizedBox(height: 9.v),
                      Padding(
                          padding: EdgeInsets.only(left: 21.h, right: 114.h),
                          child: _buildGoalSetup(
                              goalSetupText: "lbl_goal_setup".tr,
                              onTapGoalSetup: () {
                                onTapGoalSetup1();
                              })),
                      SizedBox(height: 9.v),
                      GestureDetector(
                          onTap: () {
                            onTapSeventyOne();
                          },
                          child: Padding(
                              padding: EdgeInsets.only(left: 21.h),
                              child: Row(children: [
                                CustomIconButton(
                                    height: 44.adaptSize,
                                    width: 44.adaptSize,
                                    padding: EdgeInsets.all(7.h),
                                    decoration:
                                        IconButtonStyleHelper.outlineBlueGray,
                                    child: CustomImageView(
                                        imagePath:
                                            ImageConstant.imgVideoCamera)),
                                Padding(
                                    padding: EdgeInsets.only(
                                        left: 19.h, top: 9.v, bottom: 9.v),
                                    child: Text("lbl_notification".tr,
                                        style: theme.textTheme.titleLarge)),
                                CustomImageView(
                                    imagePath: ImageConstant.imgCocoLineArrow,
                                    height: 23.v,
                                    width: 21.h,
                                    margin: EdgeInsets.only(
                                        left: 25.h, top: 11.v, bottom: 8.v))
                              ]))),
                      SizedBox(height: 12.v),
                      GestureDetector(
                          onTap: () {
                            onTapSeventyTwo();
                          },
                          child: Padding(
                              padding:
                                  EdgeInsets.only(left: 21.h, right: 117.h),
                              child: Row(children: [
                                CustomIconButton(
                                    height: 44.adaptSize,
                                    width: 44.adaptSize,
                                    padding: EdgeInsets.all(8.h),
                                    decoration:
                                        IconButtonStyleHelper.outlineBlueGray,
                                    child: CustomImageView(
                                        imagePath: ImageConstant
                                            .imgUserPrimarycontainer44x44)),
                                Padding(
                                    padding: EdgeInsets.only(
                                        left: 17.h, top: 11.v, bottom: 7.v),
                                    child: Text("lbl_settings".tr,
                                        style: theme.textTheme.titleLarge)),
                                Spacer(),
                                CustomImageView(
                                    imagePath: ImageConstant.imgCocoLineArrow,
                                    height: 23.v,
                                    width: 21.h,
                                    margin:
                                        EdgeInsets.only(top: 9.v, bottom: 10.v))
                              ]))),
                      Spacer(),
                      Divider(
                          color: theme.colorScheme.onErrorContainer
                              .withOpacity(1)),
                      SizedBox(height: 11.v),
                      GestureDetector(
                          onTap: () {
                            logout();
                          },
                          child: Padding(
                              padding: EdgeInsets.only(left: 21.h),
                              child: Row(children: [
                                CustomImageView(
                                    imagePath: ImageConstant.imgArrowRight,
                                    height: 36.adaptSize,
                                    width: 36.adaptSize),
                                Padding(
                                    padding: EdgeInsets.only(
                                        left: 15.h, top: 7.v, bottom: 3.v),
                                    child: Text("lbl_log_out".tr,
                                        style:
                                            CustomTextStyles.titleLargeRegular))
                              ])))
                    ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        leadingWidth: 54.h,
        leading: AppbarLeadingIconbuttonOne(
            imagePath: ImageConstant.imgArrowLeftPrimarycontainer,
            margin: EdgeInsets.only(left: 16.h, top: 9.v, bottom: 8.v),
            onTap: () {
              onTapArrowLeft();
            }),
        title: AppbarTitle(
            text: "lbl_menu".tr, margin: EdgeInsets.only(left: 5.h)));
  }

  /// Common widget
  Widget _buildGoalSetup({
    required String goalSetupText,
    Function? onTapGoalSetup,
  }) {
    return GestureDetector(
        onTap: () {
          onTapGoalSetup!.call();
        },
        child: Row(children: [
          CustomIconButton(
              height: 44.adaptSize,
              width: 44.adaptSize,
              padding: EdgeInsets.all(9.h),
              decoration: IconButtonStyleHelper.outlineBlueGray,
              child: CustomImageView(imagePath: ImageConstant.imgGroup66)),
          Padding(
              padding: EdgeInsets.only(left: 19.h, top: 9.v, bottom: 9.v),
              child: Text(goalSetupText,
                  style: theme.textTheme.titleLarge!.copyWith(
                      color:
                          theme.colorScheme.onErrorContainer.withOpacity(1)))),
          Spacer(),
          CustomImageView(
              imagePath: ImageConstant.imgCocoLineArrow,
              height: 23.v,
              width: 21.h,
              margin: EdgeInsets.only(top: 8.v, bottom: 12.v))
        ]));
  }

  /// Navigates to the previous screen.
  onTapArrowLeft() {
    Get.back();
  }

  /// Navigates to the statisticsScreen when the action is triggered.
  onTapSixtyEight() {
    Get.toNamed(
      AppRoutes.statisticsScreen,
    );
  }

  /// Navigates to the familyScreen when the action is triggered.
  onTapGoalSetup() {
    Get.toNamed(
      AppRoutes.familyScreen,
    );
  }

  /// Navigates to the goalScreen when the action is triggered.
  onTapGoalSetup1() {
    Get.toNamed(
      AppRoutes.goalScreen,
    );
  }

  /// Navigates to the notificationsScreen when the action is triggered.
  onTapSeventyOne() {
    Get.toNamed(
      AppRoutes.notificationsScreen,
    );
  }

  /// Navigates to the settingsScreen when the action is triggered.
  onTapSeventyTwo() {
    Get.toNamed(
      AppRoutes.settingsScreen,
    );
  }

  /// Navigates to the loginpageScreen when the action is triggered.
  logout() {
    Get.offAllNamed(
      AppRoutes.loginpageScreen,
    );
  }
}
