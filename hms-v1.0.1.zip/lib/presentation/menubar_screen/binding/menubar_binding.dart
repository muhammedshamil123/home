import '../controller/menubar_controller.dart';
import 'package:get/get.dart';

/// A binding class for the MenubarScreen.
///
/// This class ensures that the MenubarController is created when the
/// MenubarScreen is first loaded.
class MenubarBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => MenubarController());
  }
}
