import 'package:hms/core/app_export.dart';
import 'package:hms/presentation/menubar_screen/models/menubar_model.dart';

/// A controller class for the MenubarScreen.
///
/// This class manages the state of the MenubarScreen, including the
/// current menubarModelObj
class MenubarController extends GetxController {
  Rx<MenubarModel> menubarModelObj = MenubarModel().obs;
}
