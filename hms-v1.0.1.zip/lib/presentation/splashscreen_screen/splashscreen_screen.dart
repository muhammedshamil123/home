import 'controller/splashscreen_controller.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';

class SplashscreenScreen extends GetWidget<SplashscreenController> {
  const SplashscreenScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.only(left: 41.h, top: 141.v, right: 41.h),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomImageView(
                          imagePath: ImageConstant.imgRectangle15,
                          height: 111.v,
                          width: 175.h,
                          margin: EdgeInsets.only(left: 40.h)),
                      SizedBox(height: 29.v),
                      Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("lbl_welcome".tr,
                                style: CustomTextStyles.headlineLargeLight),
                            Text("lbl_home2".tr,
                                style: CustomTextStyles.headlineLargeAmber600)
                          ]),
                      SizedBox(height: 5.v)
                    ]))));
  }
}
