import 'controller/main_container_controller.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/presentation/calendar_page/calendar_page.dart';
import 'package:hms/presentation/main_page/main_page.dart';
import 'package:hms/presentation/savings_page/savings_page.dart';
import 'package:hms/widgets/custom_bottom_bar.dart';

class MainContainerScreen extends GetWidget<MainContainerController> {
  const MainContainerScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Navigator(
                key: Get.nestedKey(1),
                initialRoute: AppRoutes.mainPage,
                onGenerateRoute: (routeSetting) => GetPageRoute(
                    page: () => getCurrentPage(routeSetting.name!),
                    transition: Transition.noTransition)),
            bottomNavigationBar: Padding(
                padding: EdgeInsets.symmetric(horizontal: 11.h),
                child: _buildBottomBarColumn())));
  }

  /// Section Widget
  Widget _buildBottomBarColumn() {
    return CustomBottomBar(onChanged: (BottomBarEnum type) {
      Get.toNamed(getCurrentRoute(type), id: 1);
    });
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.mainPage;
      case BottomBarEnum.Transactions:
        return AppRoutes.savingsPage;
      case BottomBarEnum.Calendar:
        return AppRoutes.calendarPage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.mainPage:
        return MainPage();
      case AppRoutes.savingsPage:
        return SavingsPage();
      case AppRoutes.calendarPage:
        return CalendarPage();
      default:
        return DefaultWidget();
    }
  }
}
