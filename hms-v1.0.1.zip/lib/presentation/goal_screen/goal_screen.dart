import 'controller/goal_controller.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/app_bar/appbar_leading_iconbutton.dart';
import 'package:hms/widgets/app_bar/appbar_subtitle_two.dart';
import 'package:hms/widgets/app_bar/appbar_trailing_image.dart';
import 'package:hms/widgets/app_bar/custom_app_bar.dart';
import 'package:hms/widgets/custom_checkbox_button.dart';

class GoalScreen extends GetWidget<GoalController> {
  const GoalScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 2.h),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                          padding: EdgeInsets.only(left: 42.h, right: 26.h),
                          child: _buildSeventyNine(
                              expenseText: "lbl_income".tr,
                              amountText: "lbl_1_00_0002".tr)),
                      SizedBox(height: 45.v),
                      Padding(
                          padding: EdgeInsets.only(left: 42.h, right: 26.h),
                          child: _buildSeventyNine(
                              expenseText: "lbl_expense".tr,
                              amountText: "lbl_75_0002".tr)),
                      SizedBox(height: 44.v),
                      Padding(
                          padding: EdgeInsets.only(left: 42.h, right: 26.h),
                          child: _buildSeventyNine(
                              expenseText: "lbl_savings".tr,
                              amountText: "lbl_25_0002".tr)),
                      SizedBox(height: 20.v),
                      Align(
                          alignment: Alignment.centerRight,
                          child: Padding(
                              padding: EdgeInsets.only(right: 24.h),
                              child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Padding(
                                        padding: EdgeInsets.only(top: 1.v),
                                        child: Text("lbl_edit".tr,
                                            style: CustomTextStyles
                                                .bodySmallPurple300)),
                                    CustomImageView(
                                        imagePath:
                                            ImageConstant.imgEditPurple300,
                                        height: 15.adaptSize,
                                        width: 15.adaptSize)
                                  ]))),
                      SizedBox(height: 51.v),
                      _buildVectorStack(),
                      SizedBox(height: 15.v),
                      Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                              padding: EdgeInsets.only(left: 28.h),
                              child: Row(children: [
                                _buildCurrentTemperature(),
                                Container(
                                    height: 16.v,
                                    width: 15.h,
                                    margin: EdgeInsets.only(left: 23.h),
                                    decoration: BoxDecoration(
                                        color: appTheme.purple300)),
                                Padding(
                                    padding: EdgeInsets.only(left: 8.h),
                                    child: Text("lbl_goal".tr,
                                        style: theme.textTheme.bodySmall))
                              ]))),
                      SizedBox(height: 5.v)
                    ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        leadingWidth: 55.h,
        leading: AppbarLeadingIconbutton(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 17.h, top: 2.v, bottom: 15.v),
            onTap: () {
              onTapArrowLeft();
            }),
        centerTitle: true,
        title: AppbarSubtitleTwo(
            text: "lbl_goal".tr,
            margin: EdgeInsets.only(top: 28.v, bottom: 2.v)),
        actions: [
          AppbarTrailingImage(
              imagePath: ImageConstant.imgMenuVertical,
              margin: EdgeInsets.fromLTRB(7.h, 4.v, 7.h, 23.v),
              onTap: () {
                menu();
              })
        ]);
  }

  /// Section Widget
  Widget _buildVectorStack() {
    return SizedBox(
        height: 241.v,
        width: 354.h,
        child: Stack(alignment: Alignment.topLeft, children: [
          Align(
              alignment: Alignment.bottomRight,
              child: Padding(
                  padding: EdgeInsets.only(left: 54.h),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Divider(
                        color:
                            theme.colorScheme.onErrorContainer.withOpacity(1)),
                    Padding(
                        padding: EdgeInsets.symmetric(horizontal: 28.h),
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(children: [
                                Container(
                                    height: 7.v,
                                    width: 1.h,
                                    decoration: BoxDecoration(
                                        color: theme
                                            .colorScheme.onErrorContainer
                                            .withOpacity(1))),
                                SizedBox(height: 10.v),
                                Text("lbl_income".tr,
                                    style: theme.textTheme.bodySmall)
                              ]),
                              Padding(
                                  padding: EdgeInsets.only(top: 3.v),
                                  child: Column(children: [
                                    Container(
                                        height: 7.v,
                                        width: 1.h,
                                        decoration: BoxDecoration(
                                            color: theme
                                                .colorScheme.onErrorContainer
                                                .withOpacity(1))),
                                    SizedBox(height: 8.v),
                                    Text("lbl_expenses".tr,
                                        style: theme.textTheme.bodySmall)
                                  ])),
                              Column(children: [
                                Container(
                                    height: 7.v,
                                    width: 1.h,
                                    decoration: BoxDecoration(
                                        color: theme
                                            .colorScheme.onErrorContainer
                                            .withOpacity(1))),
                                SizedBox(height: 12.v),
                                Text("lbl_savings".tr,
                                    style: theme.textTheme.bodySmall)
                              ])
                            ]))
                  ]))),
          Align(
              alignment: Alignment.topLeft,
              child: Row(children: [
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("lbl_100000".tr,
                            textAlign: TextAlign.right,
                            style: theme.textTheme.bodySmall),
                        Container(
                            height: 1.v,
                            width: 6.h,
                            margin: EdgeInsets.only(
                                left: 5.h, top: 4.v, bottom: 9.v),
                            decoration: BoxDecoration(
                                color: theme.colorScheme.onErrorContainer
                                    .withOpacity(1)))
                      ]),
                  SizedBox(height: 30.v),
                  Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                    Text("lbl_75000".tr, style: theme.textTheme.bodySmall),
                    Container(
                        height: 1.v,
                        width: 6.h,
                        margin:
                            EdgeInsets.only(left: 5.h, top: 9.v, bottom: 4.v),
                        decoration: BoxDecoration(
                            color: theme.colorScheme.onErrorContainer
                                .withOpacity(1)))
                  ]),
                  SizedBox(height: 35.v),
                  Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                    Text("lbl_50000".tr, style: theme.textTheme.bodySmall),
                    Container(
                        height: 1.v,
                        width: 6.h,
                        margin:
                            EdgeInsets.only(left: 5.h, top: 9.v, bottom: 4.v),
                        decoration: BoxDecoration(
                            color: theme.colorScheme.onErrorContainer
                                .withOpacity(1)))
                  ]),
                  SizedBox(height: 35.v),
                  Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                    Text("lbl_25000".tr, style: theme.textTheme.bodySmall),
                    Container(
                        height: 1.v,
                        width: 6.h,
                        margin:
                            EdgeInsets.only(left: 5.h, top: 9.v, bottom: 4.v),
                        decoration: BoxDecoration(
                            color: theme.colorScheme.onErrorContainer
                                .withOpacity(1)))
                  ]),
                  SizedBox(height: 35.v),
                  Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                    Text("lbl_0".tr, style: theme.textTheme.bodySmall),
                    Container(
                        height: 1.v,
                        width: 6.h,
                        margin:
                            EdgeInsets.only(left: 5.h, top: 9.v, bottom: 4.v),
                        decoration: BoxDecoration(
                            color: theme.colorScheme.onErrorContainer
                                .withOpacity(1)))
                  ])
                ]),
                SizedBox(
                    height: 210.v,
                    child: VerticalDivider(
                        width: 1.h,
                        thickness: 1.v,
                        color:
                            theme.colorScheme.onErrorContainer.withOpacity(1),
                        indent: 4.h,
                        endIndent: 5.h))
              ])),
          CustomImageView(
              imagePath: ImageConstant.imgGroupBlueGray100,
              height: 201.v,
              width: 299.h,
              alignment: Alignment.topRight,
              margin: EdgeInsets.only(top: 4.v)),
          CustomImageView(
              imagePath: ImageConstant.imgGroupPurple300,
              height: 201.v,
              width: 235.h,
              alignment: Alignment.topCenter,
              margin: EdgeInsets.only(top: 4.v)),
          CustomImageView(
              imagePath: ImageConstant.imgGroupOnerrorcontainer,
              height: 103.v,
              width: 235.h,
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(right: 11.h, bottom: 35.v))
        ]));
  }

  /// Section Widget
  Widget _buildCurrentTemperature() {
    return Obx(() => CustomCheckboxButton(
        text: "lbl_current".tr,
        value: controller.currentTemperature.value,
        onChange: (value) {
          controller.currentTemperature.value = value;
        }));
  }

  /// Common widget
  Widget _buildSeventyNine({
    required String expenseText,
    required String amountText,
  }) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(expenseText,
          style: CustomTextStyles.headlineSmallDeeppurple300
              .copyWith(color: appTheme.deepPurple300)),
      Text(amountText,
          style: CustomTextStyles.headlineSmallMedium.copyWith(
              color: theme.colorScheme.onErrorContainer.withOpacity(1)))
    ]);
  }

  /// Navigates to the previous screen.
  onTapArrowLeft() {
    Get.back();
  }

  /// Navigates to the menubarScreen when the action is triggered.
  menu() {
    Get.toNamed(
      AppRoutes.menubarScreen,
    );
  }
}
