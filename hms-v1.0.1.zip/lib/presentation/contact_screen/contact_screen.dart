import 'controller/contact_controller.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/custom_elevated_button.dart';

class ContactScreen extends GetWidget<ContactController> {
  const ContactScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: appTheme.blueGray200,
            body: Container(
                width: 339.h,
                padding: EdgeInsets.symmetric(horizontal: 12.h, vertical: 19.v),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                          padding: EdgeInsets.only(left: 104.h),
                          child: Text("lbl_contact_us".tr,
                              style: CustomTextStyles.titleMediumPoppins)),
                      SizedBox(height: 7.v),
                      _buildContactDescription(),
                      SizedBox(height: 18.v),
                      CustomElevatedButton(
                          height: 37.v,
                          width: 135.h,
                          text: "lbl_close".tr,
                          buttonStyle: CustomButtonStyles.fillBlueGray,
                          buttonTextStyle: CustomTextStyles.titleSmallBlack900,
                          onPressed: () {
                            onBackPressed();
                          },
                          alignment: Alignment.center),
                      SizedBox(height: 5.v)
                    ]))));
  }

  /// Section Widget
  Widget _buildContactDescription() {
    return Align(
        alignment: Alignment.centerRight,
        child: Padding(
            padding: EdgeInsets.only(left: 17.h),
            child: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
              Container(
                  width: 140.h,
                  margin: EdgeInsets.only(top: 1.v),
                  child: Text("msg_aleena_rajan_anagha".tr,
                      maxLines: 7,
                      overflow: TextOverflow.ellipsis,
                      style: CustomTextStyles.titleSmallBlack900)),
              Container(
                  width: 115.h,
                  margin: EdgeInsets.only(left: 42.h),
                  child: Text("msg_91_8590969173_91".tr,
                      maxLines: 7,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.right,
                      style: CustomTextStyles.titleSmallBlack900))
            ])));
  }

  /// Navigates to the previous screen.
  onBackPressed() {
    Get.back();
  }
}
