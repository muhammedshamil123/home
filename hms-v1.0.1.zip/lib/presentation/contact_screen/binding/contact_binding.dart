import '../controller/contact_controller.dart';
import 'package:get/get.dart';

/// A binding class for the ContactScreen.
///
/// This class ensures that the ContactController is created when the
/// ContactScreen is first loaded.
class ContactBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => ContactController());
  }
}
