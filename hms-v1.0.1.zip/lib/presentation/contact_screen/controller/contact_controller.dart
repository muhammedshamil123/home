import 'package:hms/core/app_export.dart';
import 'package:hms/presentation/contact_screen/models/contact_model.dart';

/// A controller class for the ContactScreen.
///
/// This class manages the state of the ContactScreen, including the
/// current contactModelObj
class ContactController extends GetxController {
  Rx<ContactModel> contactModelObj = ContactModel().obs;
}
