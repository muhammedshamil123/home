import 'package:hms/core/app_export.dart';
import 'package:hms/presentation/savings_page/models/savings_model.dart';

/// A controller class for the SavingsPage.
///
/// This class manages the state of the SavingsPage, including the
/// current savingsModelObj
class SavingsController extends GetxController {
  SavingsController(this.savingsModelObj);

  Rx<SavingsModel> savingsModelObj;

  Rx<bool> currentTemperatureCheckBox = false.obs;
}
