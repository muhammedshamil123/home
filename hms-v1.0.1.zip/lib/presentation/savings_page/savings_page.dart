import 'controller/savings_controller.dart';
import 'models/savings_model.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/custom_checkbox_button.dart';
import 'package:hms/widgets/custom_floating_button.dart';
import 'package:hms/widgets/custom_icon_button.dart';

// ignore_for_file: must_be_immutable
class SavingsPage extends StatelessWidget {
  SavingsPage({Key? key}) : super(key: key);

  SavingsController controller = Get.put(SavingsController(SavingsModel().obs));

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                width: double.maxFinite,
                decoration: AppDecoration.fillPrimaryContainer,
                child: SingleChildScrollView(
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                      _buildProfilePictureRow(),
                      SizedBox(height: 420.v),
                      Padding(
                          padding: EdgeInsets.only(left: 23.h, right: 37.h),
                          child: _buildSavingsRow(
                              savingsText: "lbl_expenses".tr,
                              zeroText: "lbl_0".tr)),
                      SizedBox(height: 34.v),
                      _buildIncomeRow(),
                      SizedBox(height: 26.v),
                      Padding(
                          padding: EdgeInsets.only(left: 23.h, right: 37.h),
                          child: _buildSavingsRow(
                              savingsText: "lbl_savings".tr,
                              zeroText: "lbl_0".tr)),
                      SizedBox(height: 22.v),
                      _buildGoalStatusStack(),
                      SizedBox(height: 9.v),
                      Padding(
                          padding: EdgeInsets.only(left: 31.h),
                          child: Row(children: [
                            _buildCurrentTemperatureCheckBox(),
                            Container(
                                height: 16.v,
                                width: 15.h,
                                margin: EdgeInsets.only(left: 23.h),
                                decoration:
                                    BoxDecoration(color: appTheme.indigo600)),
                            Padding(
                                padding: EdgeInsets.only(left: 8.h),
                                child: Text("lbl_goal".tr,
                                    style: theme.textTheme.bodySmall))
                          ])),
                      SizedBox(height: 9.v)
                    ]))),
            floatingActionButton: _buildFloatingActionButton()));
  }

  /// Section Widget
  Widget _buildProfilePictureRow() {
    return Container(
        width: double.maxFinite,
        padding: EdgeInsets.symmetric(horizontal: 9.h, vertical: 7.v),
        decoration:
            BoxDecoration(borderRadius: BorderRadiusStyle.customBorderTL20),
        child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              CustomImageView(
                  imagePath: ImageConstant.imgProfilePicture,
                  height: 47.v,
                  width: 51.h,
                  radius: BorderRadius.circular(25.h),
                  margin: EdgeInsets.only(left: 19.h, top: 16.v),
                  onTap: () {
                    onTapImgProfilePicture();
                  }),
              Padding(
                  padding: EdgeInsets.only(left: 8.h, top: 14.v, bottom: 8.v),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("lbl_welcome_back".tr,
                            style:
                                CustomTextStyles.bodySmallPoppinsBluegray40001),
                        SizedBox(height: 3.v),
                        Text("lbl_jaka".tr,
                            style: CustomTextStyles.titleMediumRubik)
                      ])),
              Spacer(),
              Padding(
                  padding: EdgeInsets.only(top: 22.v, bottom: 13.v),
                  child: CustomIconButton(
                      height: 28.v,
                      width: 39.h,
                      onTap: () {
                        menu();
                      },
                      child: CustomImageView(
                          imagePath: ImageConstant.imgMenuVertical)))
            ]));
  }

  /// Section Widget
  Widget _buildIncomeRow() {
    return Padding(
        padding: EdgeInsets.only(left: 22.h, right: 37.h),
        child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                  padding: EdgeInsets.only(bottom: 8.v),
                  child: Text("lbl_income".tr,
                      style: theme.textTheme.headlineSmall)),
              Text("lbl_0".tr, style: theme.textTheme.headlineLarge)
            ]));
  }

  /// Section Widget
  Widget _buildZipcodeColumn() {
    return Align(
        alignment: Alignment.bottomCenter,
        child: Padding(
            padding: EdgeInsets.only(left: 6.h, right: 2.h),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                        padding: EdgeInsets.only(bottom: 5.v),
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Text("lbl_75000".tr,
                                        style: theme.textTheme.bodySmall),
                                    Container(
                                        height: 1.v,
                                        width: 6.h,
                                        margin: EdgeInsets.only(
                                            left: 5.h, top: 9.v, bottom: 4.v),
                                        decoration: BoxDecoration(
                                            color: theme
                                                .colorScheme.onErrorContainer
                                                .withOpacity(1)))
                                  ]),
                              SizedBox(height: 35.v),
                              Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Text("lbl_50000".tr,
                                        style: theme.textTheme.bodySmall),
                                    Container(
                                        height: 1.v,
                                        width: 6.h,
                                        margin: EdgeInsets.only(
                                            left: 5.h, top: 9.v, bottom: 4.v),
                                        decoration: BoxDecoration(
                                            color: theme
                                                .colorScheme.onErrorContainer
                                                .withOpacity(1)))
                                  ]),
                              SizedBox(height: 35.v),
                              Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Text("lbl_25000".tr,
                                        style: theme.textTheme.bodySmall),
                                    Container(
                                        height: 1.v,
                                        width: 6.h,
                                        margin: EdgeInsets.only(
                                            left: 5.h, top: 9.v, bottom: 4.v),
                                        decoration: BoxDecoration(
                                            color: theme
                                                .colorScheme.onErrorContainer
                                                .withOpacity(1)))
                                  ]),
                              SizedBox(height: 35.v),
                              Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Text("lbl_0".tr,
                                        style: theme.textTheme.bodySmall),
                                    Container(
                                        height: 1.v,
                                        width: 6.h,
                                        margin: EdgeInsets.only(
                                            left: 5.h, top: 9.v, bottom: 4.v),
                                        decoration: BoxDecoration(
                                            color: theme
                                                .colorScheme.onErrorContainer
                                                .withOpacity(1)))
                                  ])
                            ])),
                    Expanded(
                        child: Padding(
                            padding: EdgeInsets.only(top: 9.v),
                            child: Column(children: [
                              Align(
                                  alignment: Alignment.centerRight,
                                  child: Container(
                                      height: 150.v,
                                      width: 235.h,
                                      margin: EdgeInsets.only(right: 11.h),
                                      child: Stack(
                                          alignment: Alignment.bottomCenter,
                                          children: [
                                            Align(
                                                alignment:
                                                    Alignment.centerRight,
                                                child: Container(
                                                    width: 136.h,
                                                    margin: EdgeInsets.only(
                                                        left: 55.h,
                                                        right: 43.h),
                                                    child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceBetween,
                                                        children: [
                                                          Container(
                                                              height: 150.v,
                                                              width: 38.h,
                                                              decoration: BoxDecoration(
                                                                  color: appTheme
                                                                      .indigo600)),
                                                          CustomImageView(
                                                              imagePath:
                                                                  ImageConstant
                                                                      .imgGroupIndigo600,
                                                              height: 49.v,
                                                              width: 38.h,
                                                              margin: EdgeInsets
                                                                  .only(
                                                                      top: 101
                                                                          .v))
                                                        ]))),
                                            CustomImageView(
                                                imagePath: ImageConstant
                                                    .imgGroupOnerrorcontainer,
                                                height: 103.v,
                                                width: 235.h,
                                                alignment:
                                                    Alignment.bottomCenter)
                                          ]))),
                              SizedBox(
                                  height: 11.v,
                                  width: 299.h,
                                  child: Stack(
                                      alignment: Alignment.topLeft,
                                      children: [
                                        Align(
                                            alignment: Alignment.topCenter,
                                            child: SizedBox(
                                                width: 299.h,
                                                child: Divider(
                                                    color: theme.colorScheme
                                                        .onErrorContainer
                                                        .withOpacity(1)))),
                                        Align(
                                            alignment: Alignment.topLeft,
                                            child: Container(
                                                height: 7.v,
                                                width: 1.h,
                                                margin:
                                                    EdgeInsets.only(left: 50.h),
                                                decoration: BoxDecoration(
                                                    color: theme.colorScheme
                                                        .onErrorContainer
                                                        .withOpacity(1)))),
                                        Align(
                                            alignment: Alignment.topRight,
                                            child: Container(
                                                height: 7.v,
                                                width: 1.h,
                                                margin: EdgeInsets.only(
                                                    right: 48.h),
                                                decoration: BoxDecoration(
                                                    color: theme.colorScheme
                                                        .onErrorContainer
                                                        .withOpacity(1)))),
                                        Align(
                                            alignment: Alignment.bottomCenter,
                                            child: Container(
                                                height: 7.v,
                                                width: 1.h,
                                                decoration: BoxDecoration(
                                                    color: theme.colorScheme
                                                        .onErrorContainer
                                                        .withOpacity(1))))
                                      ]))
                            ])))
                  ]),
              SizedBox(height: 7.v),
              Align(
                  alignment: Alignment.centerRight,
                  child: Padding(
                      padding: EdgeInsets.only(left: 78.h, right: 28.h),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text("lbl_income".tr,
                                style: theme.textTheme.bodySmall),
                            Spacer(flex: 51),
                            Text("lbl_expenses".tr,
                                style: theme.textTheme.bodySmall),
                            Spacer(flex: 48),
                            Text("lbl_savings".tr,
                                style: theme.textTheme.bodySmall)
                          ])))
            ])));
  }

  /// Section Widget
  Widget _buildGoalStatusStack() {
    return SizedBox(
        height: 315.v,
        width: double.maxFinite,
        child: Stack(alignment: Alignment.topLeft, children: [
          Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                  height: 261.v,
                  width: 357.h,
                  padding: EdgeInsets.symmetric(vertical: 6.v),
                  decoration: AppDecoration.fillBlueGray,
                  child: Stack(alignment: Alignment.topLeft, children: [
                    Align(
                        alignment: Alignment.topLeft,
                        child: Padding(
                            padding: EdgeInsets.only(left: 55.h),
                            child: SizedBox(
                                height: 211.v,
                                child: VerticalDivider(
                                    width: 1.h,
                                    thickness: 1.v,
                                    color: theme.colorScheme.onErrorContainer
                                        .withOpacity(1),
                                    indent: 10.h)))),
                    Align(
                        alignment: Alignment.topLeft,
                        child: Padding(
                            padding: EdgeInsets.only(top: 6.v),
                            child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text("lbl_100000".tr,
                                      textAlign: TextAlign.right,
                                      style: theme.textTheme.bodySmall),
                                  Container(
                                      height: 1.v,
                                      width: 6.h,
                                      margin: EdgeInsets.only(
                                          left: 5.h, top: 4.v, bottom: 9.v),
                                      decoration: BoxDecoration(
                                          color: theme
                                              .colorScheme.onErrorContainer
                                              .withOpacity(1)))
                                ]))),
                    CustomImageView(
                        imagePath: ImageConstant.imgGroupBlueGray100,
                        height: 201.v,
                        width: 299.h,
                        alignment: Alignment.topRight,
                        margin: EdgeInsets.only(top: 10.v, right: 2.h)),
                    Align(
                        alignment: Alignment.topLeft,
                        child: Container(
                            height: 201.v,
                            width: 38.h,
                            margin: EdgeInsets.only(left: 64.h, top: 10.v),
                            decoration:
                                BoxDecoration(color: appTheme.indigo600))),
                    _buildZipcodeColumn()
                  ]))),
          Align(
              alignment: Alignment.topLeft,
              child: Padding(
                  padding: EdgeInsets.only(left: 22.h, top: 11.v),
                  child: Text("lbl_goal_status".tr,
                      style: theme.textTheme.headlineSmall))),
          Align(
              alignment: Alignment.topCenter,
              child: Container(
                  height: 111.v,
                  width: double.maxFinite,
                  decoration:
                      BoxDecoration(color: theme.colorScheme.primaryContainer)))
        ]));
  }

  /// Section Widget
  Widget _buildCurrentTemperatureCheckBox() {
    return Obx(() => CustomCheckboxButton(
        text: "lbl_current".tr,
        value: controller.currentTemperatureCheckBox.value,
        onChange: (value) {
          controller.currentTemperatureCheckBox.value = value;
        }));
  }

  /// Section Widget
  Widget _buildFloatingActionButton() {
    return CustomFloatingButton(
        height: 50,
        width: 50,
        backgroundColor: theme.colorScheme.primary,
        onTap: () {
          addtransaction();
        },
        child: CustomImageView(
            imagePath: ImageConstant.imgPlus, height: 25.0.v, width: 25.0.h));
  }

  /// Common widget
  Widget _buildSavingsRow({
    required String savingsText,
    required String zeroText,
  }) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Padding(
          padding: EdgeInsets.only(top: 6.v, bottom: 2.v),
          child: Text(savingsText,
              style: theme.textTheme.headlineSmall!.copyWith(
                  color: theme.colorScheme.onErrorContainer.withOpacity(1)))),
      Text(zeroText,
          style: theme.textTheme.headlineLarge!.copyWith(
              color: theme.colorScheme.onErrorContainer.withOpacity(1)))
    ]);
  }

  /// Navigates to the profileScreen when the action is triggered.
  onTapImgProfilePicture() {
    Get.toNamed(
      AppRoutes.profileScreen,
    );
  }

  /// Navigates to the menubarScreen when the action is triggered.
  menu() {
    Get.toNamed(
      AppRoutes.menubarScreen,
    );
  }

  /// Navigates to the addTransactionsScreen when the action is triggered.
  addtransaction() {
    Get.toNamed(
      AppRoutes.addTransactionsScreen,
    );
  }
}
