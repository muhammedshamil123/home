import '../controller/notifications_controller.dart';
import '../models/newsection_item_model.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/custom_icon_button.dart';

// ignore: must_be_immutable
class NewsectionItemWidget extends StatelessWidget {
  NewsectionItemWidget(
    this.newsectionItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  NewsectionItemModel newsectionItemModelObj;

  var controller = Get.find<NotificationsController>();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 88.v,
      width: 310.h,
      child: Stack(
        alignment: Alignment.topRight,
        children: [
          Align(
            alignment: Alignment.center,
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 20.h),
              decoration: AppDecoration.outlineBlack.copyWith(
                borderRadius: BorderRadiusStyle.roundedBorder16,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: EdgeInsets.only(
                      left: 7.h,
                      top: 1.v,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "msg_29_june_2021_7_14".tr,
                          style: theme.textTheme.labelMedium,
                        ),
                        SizedBox(height: 2.v),
                        SizedBox(
                          width: 184.h,
                          child: RichText(
                            text: TextSpan(
                              children: [
                                TextSpan(
                                  text: "lbl_you".tr,
                                  style: CustomTextStyles.labelLargeff363853,
                                ),
                                TextSpan(
                                  text: "lbl_received".tr,
                                  style: CustomTextStyles.labelLargeff363853,
                                ),
                                TextSpan(
                                  text: "msg_rp_100_000_from".tr,
                                  style: CustomTextStyles.labelLargeff363853,
                                ),
                              ],
                            ),
                            textAlign: TextAlign.left,
                          ),
                        ),
                        Text(
                          "lbl_pay_debt".tr,
                          style: theme.textTheme.labelMedium,
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                      top: 21.v,
                      bottom: 22.v,
                    ),
                    child: CustomIconButton(
                      height: 20.adaptSize,
                      width: 20.adaptSize,
                      padding: EdgeInsets.all(2.h),
                      child: CustomImageView(
                        imagePath: ImageConstant.imgCocoLineArrowLightGreenA700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment.topRight,
            child: Container(
              height: 6.adaptSize,
              width: 6.adaptSize,
              margin: EdgeInsets.only(right: 9.h),
              decoration: BoxDecoration(
                color: theme.colorScheme.secondaryContainer,
                borderRadius: BorderRadius.circular(
                  3.h,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
