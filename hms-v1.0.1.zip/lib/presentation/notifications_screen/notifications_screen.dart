import '../notifications_screen/widgets/newsection_item_widget.dart';
import 'controller/notifications_controller.dart';
import 'models/newsection_item_model.dart';
import 'package:flutter/material.dart';
import 'package:grouped_list/grouped_list.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/app_bar/appbar_leading_iconbutton.dart';
import 'package:hms/widgets/app_bar/appbar_trailing_image.dart';
import 'package:hms/widgets/app_bar/custom_app_bar.dart';

class NotificationsScreen extends GetWidget<NotificationsController> {
  const NotificationsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 20.h, vertical: 23.v),
                child: Column(children: [
                  Text("lbl_notification".tr,
                      style: CustomTextStyles.headlineSmallRubik),
                  SizedBox(height: 57.v),
                  _buildNewSection(),
                  SizedBox(height: 5.v)
                ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        leadingWidth: 53.h,
        leading: AppbarLeadingIconbutton(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 15.h, top: 9.v, bottom: 9.v),
            onTap: () {
              onTapArrowLeft();
            }),
        actions: [
          AppbarTrailingImage(
              imagePath: ImageConstant.imgMenuVertical,
              margin: EdgeInsets.fromLTRB(16.h, 12.v, 16.h, 16.v),
              onTap: () {
                menu();
              })
        ]);
  }

  /// Section Widget
  Widget _buildNewSection() {
    return Padding(
        padding: EdgeInsets.only(left: 8.h),
        child: Obx(() => GroupedListView<NewsectionItemModel, String>(
            shrinkWrap: true,
            stickyHeaderBackgroundColor: Colors.transparent,
            elements:
                controller.notificationsModelObj.value.newsectionItemList.value,
            groupBy: (element) => element.groupBy!.value,
            sort: false,
            groupSeparatorBuilder: (String value) {
              return Padding(
                  padding: EdgeInsets.only(top: 114.v, bottom: 3.v),
                  child: Column(children: [
                    Text(value,
                        style: CustomTextStyles.titleMediumPrimary
                            .copyWith(color: theme.colorScheme.primary))
                  ]));
            },
            itemBuilder: (context, model) {
              return NewsectionItemWidget(model);
            },
            separator: SizedBox(height: 1.v))));
  }

  /// Navigates to the previous screen.
  onTapArrowLeft() {
    Get.back();
  }

  /// Navigates to the menubarScreen when the action is triggered.
  menu() {
    Get.toNamed(
      AppRoutes.menubarScreen,
    );
  }
}
