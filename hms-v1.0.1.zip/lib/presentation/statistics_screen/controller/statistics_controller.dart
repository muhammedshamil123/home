import 'package:hms/core/app_export.dart';
import 'package:hms/presentation/statistics_screen/models/statistics_model.dart';

/// A controller class for the StatisticsScreen.
///
/// This class manages the state of the StatisticsScreen, including the
/// current statisticsModelObj
class StatisticsController extends GetxController {
  Rx<StatisticsModel> statisticsModelObj = StatisticsModel().obs;

  DateTime selectedopenDatePickerDialogDate = DateTime.now();

  DateTime selectedFavoriteDate = DateTime.now();
}
