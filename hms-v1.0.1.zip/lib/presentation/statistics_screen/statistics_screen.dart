import 'controller/statistics_controller.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/app_bar/appbar_iconbutton.dart';
import 'package:hms/widgets/app_bar/appbar_image.dart';
import 'package:hms/widgets/app_bar/appbar_subtitle.dart';
import 'package:hms/widgets/app_bar/custom_app_bar.dart';
import 'package:hms/widgets/custom_icon_button.dart';

class StatisticsScreen extends GetWidget<StatisticsController> {
  const StatisticsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(),
            body: SizedBox(
                width: SizeUtils.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(top: 13.v),
                    child: Container(
                        margin: EdgeInsets.only(bottom: 5.v),
                        padding: EdgeInsets.symmetric(horizontal: 25.h),
                        child: Column(children: [
                          _buildEightyEight(
                              expenseStats: "lbl_income_stats".tr,
                              text1: "lbl_oct".tr,
                              text2: "lbl_nov".tr,
                              text3: "lbl_dec".tr,
                              text4: "lbl_jan".tr,
                              text5: "lbl_feb".tr,
                              openDatePickerDialog: () {
                                openDatePickerDialog();
                              }),
                          SizedBox(height: 49.v),
                          Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                  padding: EdgeInsets.only(left: 99.h),
                                  child: Text("lbl_total_income".tr,
                                      style: CustomTextStyles
                                          .titleMediumOnPrimaryContainer))),
                          SizedBox(height: 4.v),
                          Text("lbl_13_248".tr,
                              style: theme.textTheme.displaySmall),
                          SizedBox(height: 47.v),
                          SizedBox(
                              width: 82.h,
                              child: Divider(
                                  color: theme.colorScheme.primary
                                      .withOpacity(0.28))),
                          SizedBox(height: 59.v),
                          _buildEightyEight(
                              expenseStats: "lbl_expense_stats".tr,
                              text1: "lbl_oct".tr,
                              text2: "lbl_nov".tr,
                              text3: "lbl_dec".tr,
                              text4: "lbl_jan".tr,
                              text5: "lbl_feb".tr,
                              openDatePickerDialog: () {
                                openDatePickerDialog();
                              }),
                          SizedBox(height: 50.v),
                          Text("lbl_total_expense".tr,
                              style: CustomTextStyles
                                  .titleMediumOnPrimaryContainer),
                          SizedBox(height: 3.v),
                          Text("lbl_13_248".tr,
                              style: theme.textTheme.displaySmall),
                          SizedBox(height: 47.v),
                          SizedBox(
                              width: 82.h,
                              child: Divider(
                                  color: theme.colorScheme.primary
                                      .withOpacity(0.28))),
                          SizedBox(height: 59.v),
                          _buildEightyEight(
                              expenseStats: "lbl_savings_stats".tr,
                              text1: "lbl_oct".tr,
                              text2: "lbl_nov".tr,
                              text3: "lbl_dec".tr,
                              text4: "lbl_jan".tr,
                              text5: "lbl_feb".tr,
                              openDatePickerDialog: () {
                                onTapFavorite();
                              }),
                          SizedBox(height: 50.v),
                          Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                  padding: EdgeInsets.only(left: 99.h),
                                  child: Text("lbl_total_savings".tr,
                                      style: CustomTextStyles
                                          .titleMediumOnPrimaryContainer))),
                          SizedBox(height: 3.v),
                          Text("lbl_13_248".tr,
                              style: theme.textTheme.displaySmall),
                          SizedBox(height: 37.v),
                          SizedBox(
                              width: 82.h,
                              child: Divider(
                                  color: theme.colorScheme.primary
                                      .withOpacity(0.28))),
                          SizedBox(height: 58.v),
                          _buildGoalAchievement()
                        ]))))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        height: 73.v,
        centerTitle: true,
        title: Container(
            padding: EdgeInsets.symmetric(horizontal: 14.h),
            decoration: AppDecoration.fillPrimaryContainer
                .copyWith(borderRadius: BorderRadiusStyle.customBorderTL20),
            child: Row(children: [
              AppbarIconbutton(
                  imagePath: ImageConstant.imgArrowLeft,
                  margin: EdgeInsets.only(left: 2.h, top: 35.v),
                  onTap: () {
                    onTapArrowLeft();
                  }),
              AppbarSubtitle(
                  text: "lbl_statistics".tr,
                  margin: EdgeInsets.only(left: 83.h, top: 37.v, bottom: 5.v)),
              AppbarImage(
                  imagePath: ImageConstant.imgMenuVertical,
                  margin: EdgeInsets.only(left: 63.h, top: 35.v, bottom: 10.v),
                  onTap: () {
                    menu();
                  })
            ])),
        styleType: Style.bgFill);
  }

  /// Section Widget
  Widget _buildGoalAchievement() {
    return Align(
        alignment: Alignment.centerLeft,
        child: SizedBox(
            height: 213.v,
            width: 299.h,
            child: Stack(alignment: Alignment.center, children: [
              Align(
                  alignment: Alignment.topLeft,
                  child: Text("msg_goal_achievement".tr,
                      style:
                          CustomTextStyles.titleMediumRubikDeeppurpleA20001)),
              Align(
                  alignment: Alignment.center,
                  child: Padding(
                      padding: EdgeInsets.only(left: 3.h),
                      child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Padding(
                                      padding: EdgeInsets.only(bottom: 2.v),
                                      child: Text("lbl_oct_feb".tr,
                                          style: CustomTextStyles
                                              .labelLargeBluegray500)),
                                  CustomImageView(
                                      imagePath: ImageConstant.imgFavorite,
                                      height: 20.adaptSize,
                                      width: 20.adaptSize,
                                      margin: EdgeInsets.only(left: 3.h))
                                ]),
                            SizedBox(height: 33.v),
                            CustomImageView(
                                imagePath: ImageConstant.imgGroup33515,
                                height: 111.v,
                                width: 291.h),
                            SizedBox(height: 31.v),
                            Padding(
                                padding: EdgeInsets.only(right: 5.h),
                                child: _buildExpenseStats(
                                    text1: "lbl_oct".tr,
                                    text2: "lbl_nov".tr,
                                    text3: "lbl_dec".tr,
                                    text4: "lbl_jan".tr,
                                    text5: "lbl_feb".tr))
                          ])))
            ])));
  }

  /// Common widget
  Widget _buildEightyEight({
    required String expenseStats,
    required String text1,
    required String text2,
    required String text3,
    required String text4,
    required String text5,
    Function? openDatePickerDialog,
  }) {
    return SizedBox(
        height: 213.v,
        width: 296.h,
        child: Stack(alignment: Alignment.center, children: [
          Align(
              alignment: Alignment.topLeft,
              child: Padding(
                  padding: EdgeInsets.only(left: 8.h, top: 1.v),
                  child: Text(expenseStats,
                      style: CustomTextStyles.titleMediumRubikDeeppurpleA20001
                          .copyWith(color: appTheme.deepPurpleA20001)))),
          Align(
              alignment: Alignment.center,
              child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    CustomIconButton(
                        height: 20.v,
                        width: 81.h,
                        padding: EdgeInsets.only(left: 61.h),
                        onTap: () {
                          openDatePickerDialog!.call();
                        },
                        child: CustomImageView(
                            imagePath: ImageConstant.imgFavorite)),
                    SizedBox(height: 33.v),
                    CustomImageView(
                        imagePath: ImageConstant.imgGroup33515,
                        height: 111.v,
                        width: 291.h),
                    SizedBox(height: 31.v),
                    Padding(
                        padding: EdgeInsets.only(right: 5.h),
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(text1,
                                  style: theme.textTheme.labelLarge!.copyWith(
                                      color: theme
                                          .colorScheme.onPrimaryContainer)),
                              Spacer(flex: 22),
                              Text(text2,
                                  style: theme.textTheme.labelLarge!.copyWith(
                                      color: theme
                                          .colorScheme.onPrimaryContainer)),
                              Spacer(flex: 26),
                              Text(text3,
                                  style: CustomTextStyles.labelLargeBluegray500
                                      .copyWith(color: appTheme.blueGray500)),
                              Spacer(flex: 25),
                              Text(text4,
                                  style: theme.textTheme.labelLarge!.copyWith(
                                      color: theme
                                          .colorScheme.onPrimaryContainer)),
                              Spacer(flex: 25),
                              Text(text5,
                                  style: theme.textTheme.labelLarge!.copyWith(
                                      color:
                                          theme.colorScheme.onPrimaryContainer))
                            ]))
                  ]))
        ]));
  }

  /// Common widget
  Widget _buildExpenseStats({
    required String text1,
    required String text2,
    required String text3,
    required String text4,
    required String text5,
  }) {
    return Row(mainAxisAlignment: MainAxisAlignment.end, children: [
      Text(text1,
          style: theme.textTheme.labelLarge!
              .copyWith(color: theme.colorScheme.onPrimaryContainer)),
      Spacer(flex: 22),
      Text(text2,
          style: theme.textTheme.labelLarge!
              .copyWith(color: theme.colorScheme.onPrimaryContainer)),
      Spacer(flex: 26),
      Text(text3,
          style: CustomTextStyles.labelLargeBluegray500
              .copyWith(color: appTheme.blueGray500)),
      Spacer(flex: 25),
      Text(text4,
          style: theme.textTheme.labelLarge!
              .copyWith(color: theme.colorScheme.onPrimaryContainer)),
      Spacer(flex: 25),
      Text(text5,
          style: theme.textTheme.labelLarge!
              .copyWith(color: theme.colorScheme.onPrimaryContainer))
    ]);
  }

  /// Navigates to the previous screen.
  onTapArrowLeft() {
    Get.back();
  }

  /// Navigates to the menubarScreen when the action is triggered.
  menu() {
    Get.toNamed(
      AppRoutes.menubarScreen,
    );
  }

  /// Displays a date picker dialog to update the selected date
  ///
  /// This function returns a `Future` that completes with `void`.
  Future<void> openDatePickerDialog() async {
    DateTime? dateTime = await showDatePicker(
        context: Get.context!,
        initialDate: controller.selectedopenDatePickerDialogDate,
        firstDate: DateTime(1970),
        lastDate: DateTime(
            DateTime.now().year, DateTime.now().month, DateTime.now().day));
    if (dateTime != null) {
      controller.selectedopenDatePickerDialogDate = dateTime;
    }
  }

  /// Displays a date picker dialog to update the selected date
  ///
  /// This function returns a `Future` that completes with `void`.
  Future<void> onTapFavorite() async {
    DateTime? dateTime = await showDatePicker(
        context: Get.context!,
        initialDate: controller.selectedFavoriteDate,
        firstDate: DateTime(1970),
        lastDate: DateTime(
            DateTime.now().year, DateTime.now().month, DateTime.now().day));
    if (dateTime != null) {
      controller.selectedFavoriteDate = dateTime;
    }
  }
}
