import '../controller/statistics_controller.dart';
import 'package:get/get.dart';

/// A binding class for the StatisticsScreen.
///
/// This class ensures that the StatisticsController is created when the
/// StatisticsScreen is first loaded.
class StatisticsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => StatisticsController());
  }
}
