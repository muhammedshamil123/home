import 'package:hms/core/app_export.dart';
import 'package:hms/presentation/signup_screen/models/signup_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the SignupScreen.
///
/// This class manages the state of the SignupScreen, including the
/// current signupModelObj
class SignupController extends GetxController {
  TextEditingController userNameController = TextEditingController();

  TextEditingController userEmailController = TextEditingController();

  TextEditingController userPasswordController = TextEditingController();

  TextEditingController confirmPasswordController = TextEditingController();

  Rx<SignupModel> signupModelObj = SignupModel().obs;

  @override
  void onClose() {
    super.onClose();
    userNameController.dispose();
    userEmailController.dispose();
    userPasswordController.dispose();
    confirmPasswordController.dispose();
  }
}
