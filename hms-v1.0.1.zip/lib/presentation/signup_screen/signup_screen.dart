import 'controller/signup_controller.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/custom_icon_button.dart';
import 'package:hms/widgets/custom_outlined_button.dart';
import 'package:hms/widgets/custom_text_form_field.dart';

class SignupScreen extends GetWidget<SignupController> {
  const SignupScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 13.h, vertical: 25.v),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                          padding: EdgeInsets.only(right: 85.h),
                          child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                    padding: EdgeInsets.only(bottom: 33.v),
                                    child: CustomIconButton(
                                        height: 38.adaptSize,
                                        width: 38.adaptSize,
                                        padding: EdgeInsets.all(9.h),
                                        onTap: () {
                                          onTapBtnArrowLeft();
                                        },
                                        child: CustomImageView(
                                            imagePath:
                                                ImageConstant.imgArrowLeft))),
                                Padding(
                                    padding:
                                        EdgeInsets.only(left: 57.h, top: 22.v),
                                    child: Text("lbl_sign_up".tr,
                                        style: CustomTextStyles
                                            .displayMediumOnErrorContainer))
                              ])),
                      SizedBox(height: 35.v),
                      Padding(
                          padding: EdgeInsets.only(left: 16.h),
                          child: Text("msg_your_family_name".tr,
                              style: theme.textTheme.bodyMedium)),
                      SizedBox(height: 4.v),
                      _buildUserName(),
                      SizedBox(height: 18.v),
                      Padding(
                          padding: EdgeInsets.only(left: 16.h),
                          child: Text("lbl_your_email".tr,
                              style: theme.textTheme.bodyMedium)),
                      SizedBox(height: 5.v),
                      _buildUserEmail(),
                      SizedBox(height: 12.v),
                      Padding(
                          padding: EdgeInsets.only(left: 16.h),
                          child: Text("lbl_create_password".tr,
                              style: theme.textTheme.bodyMedium)),
                      SizedBox(height: 5.v),
                      _buildUserPassword(),
                      SizedBox(height: 17.v),
                      Padding(
                          padding: EdgeInsets.only(left: 19.h),
                          child: Text("msg_confirm_password".tr,
                              style: theme.textTheme.bodyMedium)),
                      SizedBox(height: 6.v),
                      _buildConfirmPassword(),
                      SizedBox(height: 19.v),
                      Padding(
                          padding: EdgeInsets.only(right: 13.h),
                          child: CustomIconButton(
                              height: 25.v,
                              width: 35.h,
                              alignment: Alignment.centerRight,
                              onTap: () {
                                add();
                              },
                              child: CustomImageView(
                                  imagePath: ImageConstant.imgTelevision))),
                      SizedBox(height: 5.v)
                    ])),
            bottomNavigationBar: _buildSignUpButton()));
  }

  /// Section Widget
  Widget _buildUserName() {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 13.h),
        child: CustomTextFormField(
            controller: controller.userNameController,
            alignment: Alignment.center));
  }

  /// Section Widget
  Widget _buildUserEmail() {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 13.h),
        child: CustomTextFormField(
            controller: controller.userEmailController,
            alignment: Alignment.center));
  }

  /// Section Widget
  Widget _buildUserPassword() {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 13.h),
        child: CustomTextFormField(
            controller: controller.userPasswordController,
            alignment: Alignment.center,
            obscureText: true));
  }

  /// Section Widget
  Widget _buildConfirmPassword() {
    return Padding(
        padding: EdgeInsets.only(left: 16.h, right: 10.h),
        child: CustomTextFormField(
            controller: controller.confirmPasswordController,
            textInputAction: TextInputAction.done,
            alignment: Alignment.center,
            obscureText: true));
  }

  /// Section Widget
  Widget _buildSignUpButton() {
    return CustomOutlinedButton(
        text: "lbl_signup2".tr,
        margin: EdgeInsets.only(left: 19.h, right: 13.h, bottom: 32.v),
        buttonTextStyle: CustomTextStyles.headlineSmallMedium,
        onPressed: () {
          onTapSignUpButton();
        });
  }

  /// Navigates to the previous screen.
  onTapBtnArrowLeft() {
    Get.back();
  }

  /// Navigates to the addMemberScreen when the action is triggered.
  add() {
    Get.toNamed(
      AppRoutes.addMemberScreen,
    );
  }

  /// Navigates to the createHomeScreen when the action is triggered.
  onTapSignUpButton() {
    Get.toNamed(
      AppRoutes.createHomeScreen,
    );
  }
}
