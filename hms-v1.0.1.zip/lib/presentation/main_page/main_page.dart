import 'controller/main_controller.dart';
import 'models/main_model.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/custom_icon_button.dart';

// ignore_for_file: must_be_immutable
class MainPage extends StatelessWidget {
  MainPage({Key? key}) : super(key: key);

  MainController controller = Get.put(MainController(MainModel().obs));

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                width: double.maxFinite,
                decoration: AppDecoration.fillPrimaryContainer,
                child: SingleChildScrollView(
                    child: Padding(
                        padding: EdgeInsets.only(bottom: 5.v),
                        child: Column(children: [
                          _buildProfilePictureRow(),
                          SizedBox(height: 313.v),
                          Container(
                              height: 271.v,
                              width: 333.h,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20.h),
                                  border: Border.all(
                                      color: theme.colorScheme.onErrorContainer
                                          .withOpacity(1),
                                      width: 1.h)))
                        ]))))));
  }

  /// Section Widget
  Widget _buildProfilePictureRow() {
    return Container(
        width: double.maxFinite,
        padding: EdgeInsets.all(9.h),
        decoration: AppDecoration.fillPrimaryContainer
            .copyWith(borderRadius: BorderRadiusStyle.customBorderTL20),
        child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              CustomImageView(
                  imagePath: ImageConstant.imgProfilePicture,
                  height: 47.v,
                  width: 51.h,
                  radius: BorderRadius.circular(25.h),
                  margin: EdgeInsets.only(left: 19.h, top: 14.v),
                  onTap: () {
                    onTapImgProfilePicture();
                  }),
              Padding(
                  padding: EdgeInsets.only(left: 8.h, top: 12.v, bottom: 8.v),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("lbl_welcome_back".tr,
                            style:
                                CustomTextStyles.bodySmallPoppinsBluegray40001),
                        SizedBox(height: 3.v),
                        Text("lbl_jaka".tr,
                            style: CustomTextStyles.titleMediumRubik)
                      ])),
              Spacer(),
              Padding(
                  padding: EdgeInsets.only(top: 20.v, bottom: 13.v),
                  child: CustomIconButton(
                      height: 28.v,
                      width: 39.h,
                      onTap: () {
                        menubar();
                      },
                      child: CustomImageView(
                          imagePath: ImageConstant.imgMenuVertical)))
            ]));
  }

  /// Navigates to the profileScreen when the action is triggered.
  onTapImgProfilePicture() {
    Get.toNamed(
      AppRoutes.profileScreen,
    );
  }

  /// Navigates to the menubarScreen when the action is triggered.
  menubar() {
    Get.toNamed(
      AppRoutes.menubarScreen,
    );
  }
}
