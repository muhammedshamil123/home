import 'controller/next_controller.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/app_bar/appbar_leading_iconbutton.dart';
import 'package:hms/widgets/app_bar/custom_app_bar.dart';
import 'package:hms/widgets/custom_elevated_button.dart';
import 'package:hms/widgets/custom_text_form_field.dart';

class NextScreen extends GetWidget<NextController> {
  const NextScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            appBar: _buildAppBar(),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(vertical: 4.v),
                child: Column(children: [
                  Text("lbl_name_your_home".tr,
                      style: CustomTextStyles.headlineSmallBold),
                  SizedBox(height: 48.v),
                  Container(
                      width: 348.h,
                      margin: EdgeInsets.symmetric(horizontal: 6.h),
                      child: Text("msg_choose_a_nickname".tr,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: CustomTextStyles.bodyMediumOnErrorContainer)),
                  SizedBox(height: 14.v),
                  Text("lbl_it_later".tr,
                      style: CustomTextStyles.bodyMediumOnErrorContainer),
                  SizedBox(height: 26.v),
                  Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                          padding: EdgeInsets.only(left: 26.h),
                          child: Text("lbl_home_nickname".tr,
                              style: CustomTextStyles.bodyMediumBlue600))),
                  SizedBox(height: 7.v),
                  Padding(
                      padding: EdgeInsets.only(left: 24.h, right: 33.h),
                      child: CustomTextFormField(
                          controller: controller.nameController,
                          textInputAction: TextInputAction.done)),
                  SizedBox(height: 17.v),
                  SizedBox(
                      height: 450.v,
                      width: double.maxFinite,
                      child: Stack(alignment: Alignment.center, children: [
                        CustomElevatedButton(
                            width: 119.h,
                            text: "lbl_next".tr,
                            margin: EdgeInsets.only(right: 15.h, bottom: 25.v),
                            onPressed: () {
                              onTapNext();
                            },
                            alignment: Alignment.bottomRight),
                        CustomImageView(
                            imagePath: ImageConstant.imgBusinessTechnology,
                            height: 450.v,
                            width: 360.h,
                            alignment: Alignment.center)
                      ])),
                  SizedBox(height: 9.v)
                ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        leadingWidth: double.maxFinite,
        leading: AppbarLeadingIconbutton(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.fromLTRB(7.h, 9.v, 315.h, 9.v),
            onTap: () {
              onTapArrowLeft();
            }));
  }

  /// Navigates to the previous screen.
  onTapArrowLeft() {
    Get.back();
  }

  /// Navigates to the addressScreen when the action is triggered.
  onTapNext() {
    Get.toNamed(
      AppRoutes.addressScreen,
    );
  }
}
