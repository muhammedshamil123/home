import 'controller/getstarted_controller.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/custom_outlined_button.dart';

class GetstartedScreen extends GetWidget<GetstartedController> {
  const GetstartedScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 15.h, vertical: 10.v),
                child: Column(children: [
                  CustomImageView(
                      imagePath: ImageConstant.imgRectangle13,
                      height: 390.v,
                      width: 322.h),
                  SizedBox(height: 13.v),
                  Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                          width: 263.h,
                          margin: EdgeInsets.only(left: 25.h, right: 45.h),
                          child: Text("msg_forever_united_together".tr,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: CustomTextStyles.headlineLarge_1))),
                  Spacer(flex: 53),
                  CustomOutlinedButton(
                      height: 70.v,
                      text: "lbl_get_start".tr,
                      margin: EdgeInsets.only(left: 12.h, right: 8.h),
                      buttonStyle: CustomButtonStyles.outlineGrayTL201,
                      buttonTextStyle: CustomTextStyles.headlineLargeMedium,
                      onPressed: () {
                        onTapGetStart();
                      }),
                  Spacer(flex: 46)
                ]))));
  }

  /// Navigates to the loginpageScreen when the action is triggered.
  onTapGetStart() {
    Get.toNamed(
      AppRoutes.loginpageScreen,
    );
  }
}
