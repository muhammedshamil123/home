import 'controller/profile_controller.dart';
import 'package:flutter/material.dart';
import 'package:hms/core/app_export.dart';
import 'package:hms/widgets/app_bar/appbar_title_iconbutton.dart';
import 'package:hms/widgets/app_bar/appbar_title_image.dart';
import 'package:hms/widgets/app_bar/custom_app_bar.dart';
import 'package:hms/widgets/custom_icon_button.dart';

class ProfileScreen extends GetWidget<ProfileController> {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 25.h, vertical: 17.v),
                child: Column(children: [
                  Text("lbl_profile".tr,
                      style: CustomTextStyles.headlineSmallSemiBold),
                  SizedBox(height: 27.v),
                  SizedBox(
                      height: 96.adaptSize,
                      width: 96.adaptSize,
                      child: Stack(alignment: Alignment.center, children: [
                        CustomImageView(
                            imagePath: ImageConstant.imgProfilePicture96x96,
                            height: 96.adaptSize,
                            width: 96.adaptSize,
                            radius: BorderRadius.circular(48.h),
                            alignment: Alignment.center),
                        Align(
                            alignment: Alignment.center,
                            child: SizedBox(
                                height: 96.adaptSize,
                                width: 96.adaptSize,
                                child: Stack(
                                    alignment: Alignment.bottomCenter,
                                    children: [
                                      CustomImageView(
                                          imagePath:
                                              ImageConstant.imgProfilePicture1,
                                          height: 96.adaptSize,
                                          width: 96.adaptSize,
                                          alignment: Alignment.center),
                                      Align(
                                          alignment: Alignment.bottomCenter,
                                          child: Container(
                                              width: 84.h,
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 19.h,
                                                  vertical: 1.v),
                                              decoration: AppDecoration
                                                  .fillPrimaryContainer,
                                              child: Text("lbl_change".tr,
                                                  style: CustomTextStyles
                                                      .labelLargeOnErrorContainer)))
                                    ])))
                      ])),
                  SizedBox(height: 9.v),
                  Align(
                      alignment: Alignment.centerRight,
                      child: Padding(
                          padding: EdgeInsets.only(right: 95.h),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text("lbl_jaka".tr,
                                    style: CustomTextStyles.headlineSmallRubik),
                                CustomImageView(
                                    imagePath: ImageConstant.imgEdit,
                                    height: 24.adaptSize,
                                    width: 24.adaptSize,
                                    margin:
                                        EdgeInsets.only(left: 8.h, bottom: 4.v))
                              ]))),
                  SizedBox(height: 49.v),
                  _buildYourWallet(
                      privacyAndSecurityText: "msg_personal_details".tr),
                  SizedBox(height: 30.v),
                  _buildYourWallet(
                      privacyAndSecurityText: "msg_privacy_and_security".tr),
                  SizedBox(height: 30.v),
                  _buildYourWallet(
                      privacyAndSecurityText: "lbl_login_settings".tr),
                  SizedBox(height: 30.v),
                  _buildYourWallet(
                      privacyAndSecurityText: "lbl_service_center".tr),
                  Spacer(),
                  CustomIconButton(
                      height: 64.adaptSize,
                      width: 64.adaptSize,
                      padding: EdgeInsets.all(13.h),
                      decoration: IconButtonStyleHelper.outlineOnErrorContainer,
                      child: CustomImageView(
                          imagePath:
                              ImageConstant.imgThumbsUpOnerrorcontainer)),
                  SizedBox(height: 19.v),
                  Text("lbl_delete_account".tr,
                      style: CustomTextStyles.titleMediumRubik18),
                  SizedBox(height: 59.v)
                ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar() {
    return CustomAppBar(
        leadingWidth: 57.h,
        leading: AppbarTitleIconbutton(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 19.h, top: 18.v),
            onTap: () {
              onTapArrowLeft();
            }),
        title: Row(children: [
          AppbarTitleImage(
              margin: EdgeInsets.only(bottom: 28.v),
              onTap: () {
                menu();
              }),
          AppbarTitleIconbutton(
              imagePath: ImageConstant.imgArrowLeft,
              margin: EdgeInsets.only(left: 19.h, top: 18.v),
              onTap: () {
                onTapArrowLeft1();
              })
        ]));
  }

  /// Common widget
  Widget _buildYourWallet({required String privacyAndSecurityText}) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Padding(
          padding: EdgeInsets.only(top: 3.v),
          child: Text(privacyAndSecurityText,
              style: theme.textTheme.titleMedium!.copyWith(
                  color: theme.colorScheme.onErrorContainer.withOpacity(1)))),
      CustomImageView(
          imagePath: ImageConstant.imgCocoLineArrow,
          height: 24.adaptSize,
          width: 24.adaptSize)
    ]);
  }

  /// Navigates to the previous screen.
  onTapArrowLeft1() {
    Get.back();
  }

  /// Navigates to the menubarScreen when the action is triggered.
  menu() {
    Get.toNamed(
      AppRoutes.menubarScreen,
    );
  }
}
