import 'package:flutter/material.dart';
import '../core/app_export.dart';

/// A collection of pre-defined text styles for customizing text appearance,
/// categorized by different font families and weights.
/// Additionally, this class includes extensions on [TextStyle] to easily apply specific font families to text.

class CustomTextStyles {
  // Body text style
  static get bodyLargeBlack900 => theme.textTheme.bodyLarge!.copyWith(
        color: appTheme.black900,
        fontSize: 18.fSize,
      );
  static get bodyLargeBlue600 => theme.textTheme.bodyLarge!.copyWith(
        color: appTheme.blue600,
        fontSize: 18.fSize,
      );
  static get bodyLargeKatibehBluegray400 =>
      theme.textTheme.bodyLarge!.katibeh.copyWith(
        color: appTheme.blueGray400,
      );
  static get bodyLargeKatibehPrimary =>
      theme.textTheme.bodyLarge!.katibeh.copyWith(
        color: theme.colorScheme.primary,
      );
  static get bodyMediumBlue600 => theme.textTheme.bodyMedium!.copyWith(
        color: appTheme.blue600.withOpacity(0.66),
        fontWeight: FontWeight.w400,
      );
  static get bodyMediumOnErrorContainer => theme.textTheme.bodyMedium!.copyWith(
        color: theme.colorScheme.onErrorContainer.withOpacity(1),
        fontWeight: FontWeight.w400,
      );
  static get bodyMediumPoppinsBluegray40001 =>
      theme.textTheme.bodyMedium!.poppins.copyWith(
        color: appTheme.blueGray40001,
        fontSize: 14.fSize,
        fontWeight: FontWeight.w400,
      );
  static get bodyMediumPoppinsGray500 =>
      theme.textTheme.bodyMedium!.poppins.copyWith(
        color: appTheme.gray500,
        fontSize: 14.fSize,
        fontWeight: FontWeight.w400,
      );
  static get bodyMediumffffffff => theme.textTheme.bodyMedium!.copyWith(
        color: Color(0XFFFFFFFF),
        fontWeight: FontWeight.w400,
      );
  static get bodySmallPoppinsBlack900 =>
      theme.textTheme.bodySmall!.poppins.copyWith(
        color: appTheme.black900,
      );
  static get bodySmallPoppinsBlack90010 =>
      theme.textTheme.bodySmall!.poppins.copyWith(
        color: appTheme.black900.withOpacity(0.56),
        fontSize: 10.fSize,
      );
  static get bodySmallPoppinsBluegray40001 =>
      theme.textTheme.bodySmall!.poppins.copyWith(
        color: appTheme.blueGray40001,
      );
  static get bodySmallPurple300 => theme.textTheme.bodySmall!.copyWith(
        color: appTheme.purple300,
      );
  // Display text style
  static get displayMediumOnErrorContainer =>
      theme.textTheme.displayMedium!.copyWith(
        color: theme.colorScheme.onErrorContainer.withOpacity(0.7),
      );
  static get displaySmallInterOnErrorContainer =>
      theme.textTheme.displaySmall!.inter.copyWith(
        color: theme.colorScheme.onErrorContainer.withOpacity(1),
        fontWeight: FontWeight.w700,
      );
  // Headline text style
  static get headlineLargeAmber600 => theme.textTheme.headlineLarge!.copyWith(
        color: appTheme.amber600,
        fontWeight: FontWeight.w300,
      );
  static get headlineLargeLight => theme.textTheme.headlineLarge!.copyWith(
        fontWeight: FontWeight.w300,
      );
  static get headlineLargeMedium => theme.textTheme.headlineLarge!.copyWith(
        fontWeight: FontWeight.w500,
      );
  static get headlineLarge_1 => theme.textTheme.headlineLarge!;
  static get headlineSmallBlue50 => theme.textTheme.headlineSmall!.copyWith(
        color: appTheme.blue50,
      );
  static get headlineSmallBold => theme.textTheme.headlineSmall!.copyWith(
        fontWeight: FontWeight.w700,
      );
  static get headlineSmallDeeppurple300 =>
      theme.textTheme.headlineSmall!.copyWith(
        color: appTheme.deepPurple300,
        fontWeight: FontWeight.w500,
      );
  static get headlineSmallExtraBold => theme.textTheme.headlineSmall!.copyWith(
        fontWeight: FontWeight.w800,
      );
  static get headlineSmallMedium => theme.textTheme.headlineSmall!.copyWith(
        fontWeight: FontWeight.w500,
      );
  static get headlineSmallPoppins => theme.textTheme.headlineSmall!.poppins;
  static get headlineSmallRubik =>
      theme.textTheme.headlineSmall!.rubik.copyWith(
        fontWeight: FontWeight.w500,
      );
  static get headlineSmallSemiBold => theme.textTheme.headlineSmall!.copyWith(
        fontWeight: FontWeight.w600,
      );
  static get headlineSmallffffffff => theme.textTheme.headlineSmall!.copyWith(
        color: Color(0XFFFFFFFF),
      );
  // Label text style
  static get labelLargeBluegray500 => theme.textTheme.labelLarge!.copyWith(
        color: appTheme.blueGray500,
      );
  static get labelLargeErrorContainer => theme.textTheme.labelLarge!.copyWith(
        color: theme.colorScheme.errorContainer,
      );
  static get labelLargeOnErrorContainer => theme.textTheme.labelLarge!.copyWith(
        color: theme.colorScheme.onErrorContainer.withOpacity(1),
      );
  static get labelLargeff363853 => theme.textTheme.labelLarge!.copyWith(
        color: Color(0XFF363853),
      );
  // Title text style
  static get titleLargeIndigoA200 => theme.textTheme.titleLarge!.copyWith(
        color: appTheme.indigoA200,
        fontWeight: FontWeight.w400,
      );
  static get titleLargePrimary => theme.textTheme.titleLarge!.copyWith(
        color: theme.colorScheme.primary.withOpacity(0.55),
        fontWeight: FontWeight.w600,
      );
  static get titleLargePrimaryRegular => theme.textTheme.titleLarge!.copyWith(
        color: theme.colorScheme.primary.withOpacity(0.55),
        fontWeight: FontWeight.w400,
      );
  static get titleLargeRegular => theme.textTheme.titleLarge!.copyWith(
        fontWeight: FontWeight.w400,
      );
  static get titleMediumOnPrimaryContainer =>
      theme.textTheme.titleMedium!.copyWith(
        color: theme.colorScheme.onPrimaryContainer,
      );
  static get titleMediumPoppins =>
      theme.textTheme.titleMedium!.poppins.copyWith(
        fontWeight: FontWeight.w900,
      );
  static get titleMediumPoppins18 =>
      theme.textTheme.titleMedium!.poppins.copyWith(
        fontSize: 18.fSize,
      );
  static get titleMediumPrimary => theme.textTheme.titleMedium!.copyWith(
        color: theme.colorScheme.primary,
      );
  static get titleMediumRubik => theme.textTheme.titleMedium!.rubik;
  static get titleMediumRubik18 => theme.textTheme.titleMedium!.rubik.copyWith(
        fontSize: 18.fSize,
      );
  static get titleMediumRubikDeeppurpleA20001 =>
      theme.textTheme.titleMedium!.rubik.copyWith(
        color: appTheme.deepPurpleA20001,
        fontSize: 18.fSize,
      );
  static get titleSmallBlack900 => theme.textTheme.titleSmall!.copyWith(
        color: appTheme.black900,
      );
}

extension on TextStyle {
  TextStyle get katibeh {
    return copyWith(
      fontFamily: 'Katibeh',
    );
  }

  TextStyle get rubik {
    return copyWith(
      fontFamily: 'Rubik',
    );
  }

  TextStyle get inter {
    return copyWith(
      fontFamily: 'Inter',
    );
  }

  TextStyle get poppins {
    return copyWith(
      fontFamily: 'Poppins',
    );
  }

  TextStyle get quicksand {
    return copyWith(
      fontFamily: 'Quicksand',
    );
  }
}
