import 'package:hms/presentation/signup_screen/signup_screen.dart';
import 'package:hms/presentation/signup_screen/binding/signup_binding.dart';
import 'package:hms/presentation/create_home_screen/create_home_screen.dart';
import 'package:hms/presentation/create_home_screen/binding/create_home_binding.dart';
import 'package:hms/presentation/next_screen/next_screen.dart';
import 'package:hms/presentation/next_screen/binding/next_binding.dart';
import 'package:hms/presentation/address_screen/address_screen.dart';
import 'package:hms/presentation/address_screen/binding/address_binding.dart';
import 'package:hms/presentation/add_member_screen/add_member_screen.dart';
import 'package:hms/presentation/add_member_screen/binding/add_member_binding.dart';
import 'package:hms/presentation/main_container_screen/main_container_screen.dart';
import 'package:hms/presentation/main_container_screen/binding/main_container_binding.dart';
import 'package:hms/presentation/splashscreen_screen/splashscreen_screen.dart';
import 'package:hms/presentation/splashscreen_screen/binding/splashscreen_binding.dart';
import 'package:hms/presentation/getstarted_screen/getstarted_screen.dart';
import 'package:hms/presentation/getstarted_screen/binding/getstarted_binding.dart';
import 'package:hms/presentation/loginpage_screen/loginpage_screen.dart';
import 'package:hms/presentation/loginpage_screen/binding/loginpage_binding.dart';
import 'package:hms/presentation/menubar_screen/menubar_screen.dart';
import 'package:hms/presentation/menubar_screen/binding/menubar_binding.dart';
import 'package:hms/presentation/add_transactions_screen/add_transactions_screen.dart';
import 'package:hms/presentation/add_transactions_screen/binding/add_transactions_binding.dart';
import 'package:hms/presentation/profile_screen/profile_screen.dart';
import 'package:hms/presentation/profile_screen/binding/profile_binding.dart';
import 'package:hms/presentation/family_screen/family_screen.dart';
import 'package:hms/presentation/family_screen/binding/family_binding.dart';
import 'package:hms/presentation/settings_screen/settings_screen.dart';
import 'package:hms/presentation/settings_screen/binding/settings_binding.dart';
import 'package:hms/presentation/notifications_screen/notifications_screen.dart';
import 'package:hms/presentation/notifications_screen/binding/notifications_binding.dart';
import 'package:hms/presentation/statistics_screen/statistics_screen.dart';
import 'package:hms/presentation/statistics_screen/binding/statistics_binding.dart';
import 'package:hms/presentation/goal_screen/goal_screen.dart';
import 'package:hms/presentation/goal_screen/binding/goal_binding.dart';
import 'package:hms/presentation/contact_screen/contact_screen.dart';
import 'package:hms/presentation/contact_screen/binding/contact_binding.dart';
import 'package:hms/presentation/reset_password_screen/reset_password_screen.dart';
import 'package:hms/presentation/reset_password_screen/binding/reset_password_binding.dart';
import 'package:hms/presentation/app_navigation_screen/app_navigation_screen.dart';
import 'package:hms/presentation/app_navigation_screen/binding/app_navigation_binding.dart';
import 'package:get/get.dart';

class AppRoutes {
  static const String signupScreen = '/signup_screen';

  static const String createHomeScreen = '/create_home_screen';

  static const String nextScreen = '/next_screen';

  static const String addressScreen = '/address_screen';

  static const String addMemberScreen = '/add_member_screen';

  static const String mainPage = '/main_page';

  static const String mainContainerScreen = '/main_container_screen';

  static const String savingsPage = '/savings_page';

  static const String calendarPage = '/calendar_page';

  static const String splashscreenScreen = '/splashscreen_screen';

  static const String getstartedScreen = '/getstarted_screen';

  static const String loginpageScreen = '/loginpage_screen';

  static const String menubarScreen = '/menubar_screen';

  static const String addTransactionsScreen = '/add_transactions_screen';

  static const String profileScreen = '/profile_screen';

  static const String familyScreen = '/family_screen';

  static const String settingsScreen = '/settings_screen';

  static const String notificationsScreen = '/notifications_screen';

  static const String statisticsScreen = '/statistics_screen';

  static const String goalScreen = '/goal_screen';

  static const String contactScreen = '/contact_screen';

  static const String resetPasswordScreen = '/reset_password_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static List<GetPage> pages = [
    GetPage(
      name: signupScreen,
      page: () => SignupScreen(),
      bindings: [
        SignupBinding(),
      ],
    ),
    GetPage(
      name: createHomeScreen,
      page: () => CreateHomeScreen(),
      bindings: [
        CreateHomeBinding(),
      ],
    ),
    GetPage(
      name: nextScreen,
      page: () => NextScreen(),
      bindings: [
        NextBinding(),
      ],
    ),
    GetPage(
      name: addressScreen,
      page: () => AddressScreen(),
      bindings: [
        AddressBinding(),
      ],
    ),
    GetPage(
      name: addMemberScreen,
      page: () => AddMemberScreen(),
      bindings: [
        AddMemberBinding(),
      ],
    ),
    GetPage(
      name: mainContainerScreen,
      page: () => MainContainerScreen(),
      bindings: [
        MainContainerBinding(),
      ],
    ),
    GetPage(
      name: splashscreenScreen,
      page: () => SplashscreenScreen(),
      bindings: [
        SplashscreenBinding(),
      ],
    ),
    GetPage(
      name: getstartedScreen,
      page: () => GetstartedScreen(),
      bindings: [
        GetstartedBinding(),
      ],
    ),
    GetPage(
      name: loginpageScreen,
      page: () => LoginpageScreen(),
      bindings: [
        LoginpageBinding(),
      ],
    ),
    GetPage(
      name: menubarScreen,
      page: () => MenubarScreen(),
      bindings: [
        MenubarBinding(),
      ],
    ),
    GetPage(
      name: addTransactionsScreen,
      page: () => AddTransactionsScreen(),
      bindings: [
        AddTransactionsBinding(),
      ],
    ),
    GetPage(
      name: profileScreen,
      page: () => ProfileScreen(),
      bindings: [
        ProfileBinding(),
      ],
    ),
    GetPage(
      name: familyScreen,
      page: () => FamilyScreen(),
      bindings: [
        FamilyBinding(),
      ],
    ),
    GetPage(
      name: settingsScreen,
      page: () => SettingsScreen(),
      bindings: [
        SettingsBinding(),
      ],
    ),
    GetPage(
      name: notificationsScreen,
      page: () => NotificationsScreen(),
      bindings: [
        NotificationsBinding(),
      ],
    ),
    GetPage(
      name: statisticsScreen,
      page: () => StatisticsScreen(),
      bindings: [
        StatisticsBinding(),
      ],
    ),
    GetPage(
      name: goalScreen,
      page: () => GoalScreen(),
      bindings: [
        GoalBinding(),
      ],
    ),
    GetPage(
      name: contactScreen,
      page: () => ContactScreen(),
      bindings: [
        ContactBinding(),
      ],
    ),
    GetPage(
      name: resetPasswordScreen,
      page: () => ResetPasswordScreen(),
      bindings: [
        ResetPasswordBinding(),
      ],
    ),
    GetPage(
      name: appNavigationScreen,
      page: () => AppNavigationScreen(),
      bindings: [
        AppNavigationBinding(),
      ],
    ),
    GetPage(
      name: initialRoute,
      page: () => SplashscreenScreen(),
      bindings: [
        SplashscreenBinding(),
      ],
    )
  ];
}
